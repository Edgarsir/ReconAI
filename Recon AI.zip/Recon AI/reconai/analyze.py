import json

with open("reports/shopify_com_20260827_185450.json", encoding="utf-8") as f:
    data = json.load(f)

analysis   = data.get("analysis", {})
subdomains = data.get("subdomains", {})
ports      = data.get("ports", {})
github     = data.get("github", {})
wayback    = data.get("wayback", {})
shodan     = data.get("shodan", {})
bugbounty  = data.get("bugbounty", {})

print("=" * 60)
print("OVERALL")
print("=" * 60)
print(f"  Risk          : {analysis.get('overall_risk')}")
print(f"  Total findings: {analysis.get('total_findings')}")
print(f"  Critical      : {analysis.get('critical_count')}")
print(f"  High          : {analysis.get('high_count')}")
print(f"  Medium        : {analysis.get('medium_count')}")

print("\n" + "=" * 60)
print("BUG BOUNTY")
print("=" * 60)
print(f"  Programs found : {bugbounty.get('total_programs')}")
print(f"  In scope       : {bugbounty.get('in_scope_count')}")
for p in bugbounty.get("in_scope", []):
    print(f"  → {p.get('name')} | {p.get('url')}")

print("\n" + "=" * 60)
print("SUBDOMAINS")
print("=" * 60)
print(f"  Total discovered : {subdomains.get('total_found')}")
print(f"  Live             : {subdomains.get('live_count')}")
print(f"  Takeover risks   : {subdomains.get('takeover_risks')}")
for s in subdomains.get("subdomains", [])[:20]:
    cdn    = s.get("cdn", "")
    status = s.get("http_status", "")
    title  = s.get("title", "")
    ips    = ", ".join(s.get("ips", []))
    print(f"  {s['subdomain']:<40} {str(status):<6} {cdn:<15} {title[:40]}")

print("\n" + "=" * 60)
print("PORTS")
print("=" * 60)
for host, pdata in ports.items():
    print(f"  {host} — {pdata.get('total_open')} open, {pdata.get('critical_count')} critical")
    for p in pdata.get("open_ports", []):
        flag = " ← CRITICAL" if p.get("critical") else ""
        print(f"    {p['port']:<6} {p.get('service',''):<20} {flag}")

print("\n" + "=" * 60)
print("GITHUB LEAKS")
print("=" * 60)
print(f"  Files scanned : {github.get('files_scanned', 0)}")
print(f"  Leaks found   : {github.get('total_leaks')}")
print(f"  Critical      : {github.get('critical')}")
print(f"  High          : {github.get('high')}")
for f in github.get("findings", []):
    print(f"\n  [{f.get('highest_severity')}] {f.get('repo')}/{f.get('file')}")
    print(f"  URL: {f.get('url')}")
    for s in f.get("secrets", [])[:5]:
        print(f"    → [{s.get('severity')}] {s.get('type')} line {s.get('line')}: {s.get('redacted')} | {s.get('line_content','')[:80]}")
    for tm in f.get("text_matches", [])[:2]:
        print(f"    → Match: {tm.get('fragment','')[:120]}")

print("\n" + "=" * 60)
print("WAYBACK MACHINE")
print("=" * 60)
print(f"  Historical URLs : {wayback.get('total_found')}")
print(f"  Still alive     : {wayback.get('alive_count')}")
for f in wayback.get("findings", [])[:15]:
    sensitive = ", ".join(f.get("sensitive_content", []))
    print(f"  [{f.get('current_status')}] {f.get('url','')[:80]}")
    if sensitive:
        print(f"        ↑ SENSITIVE KEYWORDS: {sensitive}")

print("\n" + "=" * 60)
print("SHODAN")
print("=" * 60)
print(f"  IPs analyzed  : {shodan.get('total_ips')}")
print(f"  Total CVEs    : {shodan.get('total_vulns')}")
print(f"  Critical CVEs : {shodan.get('critical_vulns')}")
for h in shodan.get("hosts", []):
    print(f"  {h.get('ip')} | {h.get('org')} | Ports: {h.get('open_ports')}")
    for v in h.get("critical_vulns", []):
        print(f"    ⚠ CRITICAL CVE: {v.get('cve')} — {v.get('name')} (CVSS {v.get('cvss')})")

print("\n" + "=" * 60)
print("AI NARRATIVE")
print("=" * 60)
print(analysis.get("ai_summary") or "Not generated (Gemini timeout)")

print("\n" + "=" * 60)
print("TOP FINDINGS")
print("=" * 60)
for f in analysis.get("top_findings", []):
    print(f"  [{f.get('risk_score')}/10] {f.get('type','').upper()} — {f.get('target','')}")
    for n in f.get("notes", [])[:2]:
        print(f"    → {n}")
