# ReconAI - Configuration Settings

import os
from dotenv import load_dotenv

# Load .env file from project root
load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"))

# API Keys
SHODAN_API_KEY = os.getenv("SHODAN_API_KEY", "")
GITHUB_TOKEN   = os.getenv("GITHUB_TOKEN", "")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# Legacy OpenAI key (not used, kept for compatibility)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Scanning settings
DNS_TIMEOUT      = 3    # seconds per DNS query
PORT_SCAN_TIMEOUT = 2   # seconds per port
MAX_THREADS      = 50   # concurrent threads
MAX_SUBDOMAINS   = 500  # cap on subdomain checks
WAYBACK_LIMIT    = 100  # max wayback URLs to fetch

# Common ports to scan
COMMON_PORTS = [
    21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143,
    443, 445, 993, 995, 1723, 3306, 3389, 5900, 8080,
    8443, 8888, 9200, 9300, 27017, 6379, 5432, 1521,
    2375, 2376, 4243, 5000, 5001, 6443, 8001, 8081,
    8082, 9000, 9090, 9443, 10250, 10255, 16443
]

# Risk scoring weights
RISK_WEIGHTS = {
    "open_port_critical":   9,
    "open_port_high":       7,
    "open_port_medium":     5,
    "secret_found":         10,
    "dead_endpoint_alive":  6,
    "shodan_vuln":          9,
    "subdomain_takeover":   10,
}

# Critical services (high risk if exposed)
CRITICAL_SERVICES = {
    22:    "SSH",
    23:    "Telnet",
    3389:  "RDP",
    5900:  "VNC",
    3306:  "MySQL",
    5432:  "PostgreSQL",
    27017: "MongoDB",
    6379:  "Redis",
    9200:  "Elasticsearch",
    2375:  "Docker API (unencrypted)",
    10250: "Kubernetes kubelet",
}
