"""
ReconAI - AI Risk Prioritization Engine
Uses Google Gemini (via REST API) to analyze scan results, correlate findings,
assign risk scores, and generate actionable remediation advice.
Falls back to rule-based scoring when no API key is available.
"""

import json
import sys
import requests
from typing import Dict, List, Optional
from config.settings import GEMINI_API_KEY, RISK_WEIGHTS

GEMINI_AVAILABLE = True  # Uses requests (always available)


# ─── Rule-based scoring (always available) ────────────────────────────────────

def score_subdomains(subdomain_data: Dict) -> List[Dict]:
    """Score subdomain findings."""
    scored = []
    for sub in subdomain_data.get("subdomains", []):
        risk  = 0
        notes = []

        if sub.get("takeover_risk"):
            risk += RISK_WEIGHTS["subdomain_takeover"]
            notes.append("CRITICAL: Potential subdomain takeover vulnerability")

        if sub.get("cname"):
            risk += 2
            notes.append(f"CNAME chain: {sub['cname']}")

        # Add info about HTTP-discovered subdomains
        if sub.get("http_status"):
            status = sub["http_status"]
            cdn    = sub.get("cdn", "")
            title  = sub.get("title", "")
            note   = f"HTTP {status}"
            if cdn:
                note += f" via {cdn}"
            if title:
                note += f' — "{title[:60]}"'
            notes.append(note)
            if status in (200, 301, 302) and not cdn:
                risk += 3  # Higher risk if not behind CDN

        if risk > 0:
            scored.append({
                "type":       "subdomain",
                "target":     sub["subdomain"],
                "risk_score": risk,
                "notes":      notes,
                "ips":        sub.get("ips", []),
                "cdn":        sub.get("cdn", ""),
                "http_status":sub.get("http_status"),
                "title":      sub.get("title", ""),
            })
    return scored


def score_ports(port_data: Dict) -> List[Dict]:
    """Score port scan findings."""
    scored = []

    # Critical port risk map
    critical_port_risk = {
        2375: (10, "Docker API exposed without TLS — full container takeover possible"),
        3389: (9,  "RDP exposed — brute force and CVE-2019-0708 (BlueKeep) risk"),
        5900: (9,  "VNC exposed — remote desktop access possible"),
        23:   (9,  "Telnet is unencrypted — credentials transmitted in plaintext"),
        10250:(9,  "Kubernetes kubelet API exposed — node-level access possible"),
        6443: (8,  "Kubernetes API Server exposed"),
        9200: (8,  "Elasticsearch exposed — potential unauthenticated data access"),
        27017:(8,  "MongoDB exposed — check if authentication is enabled"),
        6379: (8,  "Redis exposed — often runs without authentication"),
        3306: (7,  "MySQL exposed to internet — brute force risk"),
        5432: (7,  "PostgreSQL exposed to internet"),
        22:   (3,  "SSH exposed — ensure key-based auth only, no password login"),
    }

    for host, data in port_data.items():
        for port_info in data.get("open_ports", []):
            port = port_info["port"]
            risk = 0
            notes = []

            if port in critical_port_risk:
                risk, note = critical_port_risk[port]
                notes.append(note)
            elif port_info.get("critical"):
                risk = RISK_WEIGHTS["open_port_high"]
                notes.append(f"Potentially sensitive service: {port_info['service']}")
            else:
                risk = RISK_WEIGHTS["open_port_medium"]

            # Check HTTP probe findings
            http = port_info.get("http_probe", {})
            for path_finding in http.get("paths", []):
                if path_finding.get("interesting"):
                    sev = path_finding.get("severity", "MEDIUM")
                    extra = 5 if sev == "HIGH" else 3
                    risk += extra
                    notes.append(
                        f"Sensitive path accessible: {path_finding['path']} "
                        f"(HTTP {path_finding['status']})"
                    )

            scored.append({
                "type": "port",
                "target": f"{host}:{port}",
                "service": port_info["service"],
                "risk_score": min(risk, 10),
                "notes": notes,
                "banner": port_info.get("banner"),
            })

    return scored


def score_github(github_data: Dict) -> List[Dict]:
    """Score GitHub secret findings with full detail."""
    scored = []
    severity_score = {"CRITICAL": 10, "HIGH": 8, "MEDIUM": 5}

    for finding in github_data.get("findings", []):
        highest_sev = finding.get("highest_severity", "MEDIUM")
        risk        = severity_score.get(highest_sev, 5)
        secrets     = finding.get("secrets", [])
        text_matches = finding.get("text_matches", [])

        # Build detailed notes
        notes = []
        for s in secrets[:5]:
            notes.append(
                f"[{s['severity']}] {s['type']} on line {s.get('line','?')}: "
                f"{s.get('redacted','***')}  ←  {s.get('line_content','')[:80]}"
            )

        # Add GitHub's own text match fragments if no secrets decoded
        if not notes and text_matches:
            for tm in text_matches[:3]:
                fragment = tm.get("fragment", "")
                if fragment:
                    notes.append(f"GitHub match: {fragment[:120]}")

        if not notes:
            notes.append(f"Sensitive file found: {finding.get('file','')}")

        scored.append({
            "type":             "github_secret",
            "target":           f"{finding['repo']}/{finding['file']}",
            "url":              finding.get("url"),
            "repo_url":         finding.get("repo_url", ""),
            "repo_desc":        finding.get("repo_desc", ""),
            "risk_score":       risk,
            "notes":            notes,
            "secrets":          secrets,
            "text_matches":     text_matches,
            "file_preview":     finding.get("file_preview", ""),
            "secret_count":     finding.get("secret_count", 0),
        })
    return scored


def score_wayback(wayback_data: Dict) -> List[Dict]:
    """Score Wayback Machine findings."""
    scored = []
    for finding in wayback_data.get("findings", []):
        if not finding.get("alive"):
            continue
        risk = min(finding.get("score", 1) * 2, 8)
        notes = list(finding.get("reasons", []))

        if finding.get("sensitive_content"):
            risk = min(risk + 3, 10)
            notes.append(f"Sensitive keywords in response: {', '.join(finding['sensitive_content'][:3])}")

        scored.append({
            "type": "wayback_endpoint",
            "target": finding["url"],
            "risk_score": risk,
            "notes": notes,
            "status": finding.get("current_status"),
        })
    return scored


def score_shodan(shodan_data: Dict) -> List[Dict]:
    """Score Shodan vulnerability findings."""
    scored = []
    if shodan_data.get("demo"):
        return []

    for host in shodan_data.get("hosts", []):
        for vuln in host.get("critical_vulns", []):
            scored.append({
                "type": "shodan_vuln",
                "target": host.get("ip", ""),
                "risk_score": 10,
                "notes": [
                    f"KNOWN CVE: {vuln['cve']} — {vuln.get('name', '')}",
                    f"CVSS: {vuln.get('cvss', 'N/A')}",
                    vuln.get("summary", "")[:150],
                ],
                "cve": vuln["cve"],
            })
        for vuln in host.get("vulnerabilities", []):
            sev_score = {"CRITICAL": 9, "HIGH": 7, "MEDIUM": 5, "LOW": 2}.get(
                vuln.get("severity", "LOW"), 2
            )
            scored.append({
                "type": "shodan_vuln",
                "target": host.get("ip", ""),
                "risk_score": sev_score,
                "notes": [
                    f"CVE: {vuln['cve']} (CVSS {vuln.get('cvss', 'N/A')})",
                    vuln.get("summary", "")[:150],
                ],
                "cve": vuln["cve"],
            })
    return scored


def rule_based_analysis(all_findings: List[Dict]) -> Dict:
    """
    Pure rule-based risk analysis when OpenAI is unavailable.
    Assigns risk levels, groups findings, and generates remediation advice.
    """
    # Sort by risk score descending
    all_findings.sort(key=lambda x: x.get("risk_score", 0), reverse=True)

    critical = [f for f in all_findings if f.get("risk_score", 0) >= 9]
    high     = [f for f in all_findings if 7 <= f.get("risk_score", 0) < 9]
    medium   = [f for f in all_findings if 4 <= f.get("risk_score", 0) < 7]
    low      = [f for f in all_findings if f.get("risk_score", 0) < 4]

    # Calculate overall risk score
    if critical:
        overall = "CRITICAL"
        overall_score = 10
    elif high:
        overall = "HIGH"
        overall_score = 7
    elif medium:
        overall = "MEDIUM"
        overall_score = 5
    else:
        overall = "LOW"
        overall_score = 2

    # Generate rule-based remediation
    remediation = generate_remediation(all_findings)

    return {
        "overall_risk": overall,
        "overall_score": overall_score,
        "total_findings": len(all_findings),
        "critical_count": len(critical),
        "high_count": len(high),
        "medium_count": len(medium),
        "low_count": len(low),
        "top_findings": all_findings[:10],
        "all_findings": all_findings,
        "remediation": remediation,
        "ai_summary": None,
        "ai_used": False,
    }


def generate_remediation(findings: List[Dict]) -> List[Dict]:
    """Generate remediation advice based on finding types."""
    remediation = []
    types_seen = set()

    remediation_map = {
        "subdomain": {
            "title": "Investigate Subdomain Takeover Risks",
            "priority": "CRITICAL",
            "steps": [
                "Immediately audit all CNAME records pointing to external services",
                "If the CNAME target no longer exists, remove the DNS record",
                "Claim the resource on the external platform (GitHub Pages, Heroku, etc.) before attackers do",
                "Implement monitoring for CNAME resolution changes",
            ]
        },
        "port": {
            "title": "Restrict Exposed Services",
            "priority": "HIGH",
            "steps": [
                "Audit firewall rules — no database ports (3306, 5432, 27017, 6379) should be internet-facing",
                "Place admin services (RDP, VNC, SSH) behind VPN or IP allowlist",
                "Disable Telnet entirely — replace with SSH",
                "For Docker API: enable TLS authentication immediately",
                "For Kubernetes: restrict API server access to authorized CIDRs",
            ]
        },
        "github_secret": {
            "title": "Revoke and Rotate All Leaked Credentials",
            "priority": "CRITICAL",
            "steps": [
                "IMMEDIATELY revoke all exposed API keys and tokens",
                "Rotate AWS credentials, GitHub tokens, and all service passwords",
                "Enable GitHub secret scanning on all repositories",
                "Add .env, *.pem, *.key to .gitignore across all repos",
                "Audit git history — use git-filter-repo to purge secrets from history",
                "Implement pre-commit hooks (e.g., gitleaks, detect-secrets)",
            ]
        },
        "wayback_endpoint": {
            "title": "Remediate Exposed Legacy Endpoints",
            "priority": "MEDIUM",
            "steps": [
                "Audit all discovered endpoints — confirm they should be publicly accessible",
                "Remove or protect backup files (.bak, .old, .sql) immediately",
                "Ensure debug/test endpoints require authentication",
                "Review exposed admin panels and apply IP restrictions",
                "Check for exposed .git directories — serve 403 for /.git/* paths",
            ]
        },
        "shodan_vuln": {
            "title": "Patch Known Vulnerabilities Immediately",
            "priority": "CRITICAL",
            "steps": [
                "Apply all available security patches to affected systems",
                "Prioritize CVEs with public exploits (Log4Shell, EternalBlue, etc.)",
                "Implement virtual patching via WAF for exploited vulnerabilities",
                "Segment vulnerable services from the internet",
                "Subscribe to CVE feeds for your technology stack",
            ]
        },
    }

    for finding in findings:
        finding_type = finding.get("type", "")
        if finding_type not in types_seen and finding_type in remediation_map:
            types_seen.add(finding_type)
            remediation.append(remediation_map[finding_type])

    return remediation


# ─── AI-powered analysis ───────────────────────────────────────────────────────

def ai_analyze(domain: str, all_findings: List[Dict], rule_based: Dict) -> str:
    """
    Use Google Gemini REST API to generate an intelligent security narrative
    and deeper analysis of the findings.
    """
    if not GEMINI_API_KEY:
        return None

    try:
        # Prepare a compact summary for the prompt
        top_findings_summary = []
        for f in all_findings[:15]:
            top_findings_summary.append({
                "type": f.get("type"),
                "target": f.get("target"),
                "risk_score": f.get("risk_score"),
                "notes": f.get("notes", [])[:2],
            })

        prompt = f"""You are an expert penetration tester and security researcher analyzing
attack surface scan results for the domain: {domain}

Here are the top findings from automated scanning:
{json.dumps(top_findings_summary, indent=2)}

Overall risk level determined by rule engine: {rule_based['overall_risk']}
- Critical findings: {rule_based['critical_count']}
- High findings: {rule_based['high_count']}
- Medium findings: {rule_based['medium_count']}

Please provide:
1. A concise executive summary (2-3 sentences) of the security posture
2. The most critical attack chain or scenario an attacker could exploit
3. Top 3 immediate actions the security team should take
4. Any correlation between findings that increases overall risk

Be specific, actionable, and professional. Limit response to 400 words."""

        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"gemini-3.6-flash:generateContent?key={GEMINI_API_KEY}"
        )
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": 0.3,
                "maxOutputTokens": 600,
            },
            "systemInstruction": {
                "parts": [{
                    "text": (
                        "You are an expert cybersecurity analyst specializing in "
                        "attack surface management and penetration testing."
                    )
                }]
            },
        }
        resp = requests.post(url, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]

    except Exception as e:
        print(f"  [!] Gemini AI analysis failed: {e}", file=sys.stderr)
        return None


# ─── Main entry point ─────────────────────────────────────────────────────────

def run(
    domain: str,
    subdomain_data: Dict,
    port_data: Dict,
    github_data: Dict,
    wayback_data: Dict,
    shodan_data: Dict,
    verbose: bool = False
) -> Dict:
    """
    Main entry point for AI risk prioritization.
    Aggregates all module results, scores findings, and generates analysis.
    """
    print(f"\n[*] Running AI risk prioritization engine...")

    # Collect and score all findings
    all_findings = []
    all_findings.extend(score_subdomains(subdomain_data))
    all_findings.extend(score_ports(port_data))
    all_findings.extend(score_github(github_data))
    all_findings.extend(score_wayback(wayback_data))
    all_findings.extend(score_shodan(shodan_data))

    print(f"  [+] Scored {len(all_findings)} total findings")

    # Rule-based analysis (always runs)
    analysis = rule_based_analysis(all_findings)

    # AI-powered narrative (if Gemini key available)
    if GEMINI_API_KEY:
        print("  [+] Generating Gemini AI security narrative...")
        ai_summary = ai_analyze(domain, all_findings, analysis)
        if ai_summary:
            analysis["ai_summary"] = ai_summary
            analysis["ai_used"] = True
            print("  [✓] AI analysis complete")
        else:
            print("  [!] Gemini call failed — check your GEMINI_API_KEY")
    else:
        print("  [!] No GEMINI_API_KEY set — using rule-based analysis only")

    print(f"\n  [✓] Risk analysis complete:")
    print(f"      Overall risk    : {analysis['overall_risk']}")
    print(f"      Total findings  : {analysis['total_findings']}")
    print(f"      Critical        : {analysis['critical_count']}")
    print(f"      High            : {analysis['high_count']}")
    print(f"      Medium          : {analysis['medium_count']}")

    return analysis
