"""
ReconAI - Bug Bounty Integration Module
Fetches live programs from HackerOne and Bugcrowd,
checks if a target domain is in scope, and returns
bounty ranges, allowed test types, and program rules.
"""

import requests
import re
from typing import Dict, List, Optional
from urllib.parse import urlparse

HEADERS = {"User-Agent": "ReconAI/1.0"}


# ─── HackerOne ────────────────────────────────────────────────────────────────

def fetch_hackerone_programs(domain: str) -> List[Dict]:
    """
    Search HackerOne public directory for programs matching the domain.
    Uses the public GraphQL API (no auth required for public programs).
    """
    results = []
    try:
        # HackerOne public program search
        url = "https://hackerone.com/graphql"
        query = """
        query($query: String!) {
          search(query: $query, product_area: "hackerone", product_feature: "programs") {
            __typename
            ... on SearchResultConnection {
              nodes {
                ... on TeamSearchResult {
                  team {
                    name
                    handle
                    url
                    profile {
                      name
                      about
                    }
                    structured_scope_versions(archived: false) {
                      max_reward: max_reward {
                        amount
                        currency
                      }
                      in_scope {
                        asset_type
                        asset_identifier
                        eligible_for_bounty
                        max_severity
                        instruction
                      }
                      out_of_scope {
                        asset_type
                        asset_identifier
                      }
                    }
                    submission_state
                    offers_bounties
                    min_bounty_table_value
                    max_bounty_table_value
                  }
                }
              }
            }
          }
        }
        """
        payload = {"query": query, "variables": {"query": domain}}
        resp = requests.post(
            url, json=payload, headers={**HEADERS, "Content-Type": "application/json"},
            timeout=15
        )
        if resp.status_code == 200:
            data = resp.json()
            nodes = (data.get("data", {})
                        .get("search", {})
                        .get("nodes", []))
            for node in nodes:
                team = node.get("team", {})
                if not team:
                    continue
                scope_data = team.get("structured_scope_versions", {}) or {}
                in_scope = scope_data.get("in_scope", []) or []
                out_scope = scope_data.get("out_of_scope", []) or []

                results.append({
                    "platform": "HackerOne",
                    "name": team.get("profile", {}).get("name", team.get("name", "")),
                    "handle": team.get("handle", ""),
                    "url": f"https://hackerone.com/{team.get('handle', '')}",
                    "offers_bounty": team.get("offers_bounties", False),
                    "min_bounty": team.get("min_bounty_table_value"),
                    "max_bounty": team.get("max_bounty_table_value"),
                    "submission_state": team.get("submission_state", "open"),
                    "in_scope": in_scope,
                    "out_of_scope": out_scope,
                    "about": team.get("profile", {}).get("about", "")[:200],
                })
    except Exception as e:
        pass

    return results


def fetch_hackerone_directory(domain: str) -> List[Dict]:
    """
    Fallback: fetch HackerOne public directory and filter by domain.
    """
    results = []
    try:
        url = "https://hackerone.com/programs/search?query={}&sort=published_at%3Adescending&limit=25".format(
            requests.utils.quote(domain)
        )
        resp = requests.get(url, headers=HEADERS, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            for program in data.get("results", []):
                results.append({
                    "platform": "HackerOne",
                    "name": program.get("name", ""),
                    "handle": program.get("handle", ""),
                    "url": f"https://hackerone.com/{program.get('handle','')}",
                    "offers_bounty": program.get("offers_bounties", False),
                    "min_bounty": program.get("min_bounty_table_value"),
                    "max_bounty": program.get("max_bounty_table_value"),
                    "submission_state": program.get("submission_state", "open"),
                    "in_scope": [],
                    "out_of_scope": [],
                    "about": program.get("meta", {}).get("description", "")[:200],
                })
    except Exception:
        pass
    return results


# ─── Bugcrowd ─────────────────────────────────────────────────────────────────

def fetch_bugcrowd_programs(domain: str) -> List[Dict]:
    """
    Search Bugcrowd public program list for the target domain.
    """
    results = []
    try:
        url = f"https://bugcrowd.com/programs.json?search%5Bquery%5D={domain}&offset%5Bp%5D=1&limit%5Bp%5D=25"
        resp = requests.get(url, headers=HEADERS, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            for program in data.get("programs", []):
                targets = program.get("target_groups", [])
                in_scope = []
                for tg in targets:
                    for t in tg.get("targets", []):
                        in_scope.append({
                            "asset_type": t.get("category", ""),
                            "asset_identifier": t.get("name", ""),
                            "eligible_for_bounty": tg.get("in_scope", False),
                        })

                results.append({
                    "platform": "Bugcrowd",
                    "name": program.get("name", ""),
                    "handle": program.get("code", ""),
                    "url": f"https://bugcrowd.com/{program.get('code','')}",
                    "offers_bounty": program.get("max_payout", 0) > 0,
                    "min_bounty": program.get("min_payout"),
                    "max_bounty": program.get("max_payout"),
                    "submission_state": "open" if not program.get("disabled") else "closed",
                    "in_scope": in_scope,
                    "out_of_scope": [],
                    "about": program.get("tagline", "")[:200],
                })
    except Exception:
        pass
    return results


# ─── Scope checker ────────────────────────────────────────────────────────────

def domain_matches_scope(domain: str, scope_identifier: str) -> bool:
    """
    Check if a domain matches a scope entry.
    Handles wildcards like *.example.com
    """
    scope = scope_identifier.strip().lower()
    target = domain.strip().lower()

    # Remove protocol if present
    if "://" in scope:
        scope = urlparse(scope).netloc or scope
    if "://" in target:
        target = urlparse(target).netloc or target

    # Exact match
    if scope == target:
        return True

    # Wildcard match: *.example.com matches sub.example.com
    if scope.startswith("*."):
        base = scope[2:]
        if target == base or target.endswith("." + base):
            return True

    # Partial match: example.com matches api.example.com
    if target.endswith("." + scope) or target == scope:
        return True

    return False


def check_scope(domain: str, programs: List[Dict]) -> List[Dict]:
    """
    For each program, determine if the domain is in scope, out of scope, or unknown.
    Returns enriched program list with scope_status field.
    """
    enriched = []
    for program in programs:
        scope_status = "unknown"
        matched_scope = []
        bounty_eligible = False
        max_severity = None

        # Check out of scope first
        for item in program.get("out_of_scope", []):
            identifier = item.get("asset_identifier", "")
            if identifier and domain_matches_scope(domain, identifier):
                scope_status = "out_of_scope"
                break

        # Check in scope
        if scope_status != "out_of_scope":
            for item in program.get("in_scope", []):
                identifier = item.get("asset_identifier", "")
                if identifier and domain_matches_scope(domain, identifier):
                    scope_status = "in_scope"
                    bounty_eligible = item.get("eligible_for_bounty", False)
                    max_severity = item.get("max_severity")
                    matched_scope.append(identifier)

        program["scope_status"] = scope_status
        program["matched_scope"] = matched_scope
        program["bounty_eligible"] = bounty_eligible
        program["max_severity"] = max_severity
        enriched.append(program)

    return enriched


def format_bounty(min_b, max_b, currency="USD") -> str:
    """Format bounty range as a readable string."""
    if max_b and int(max_b) > 0:
        if min_b and int(min_b) > 0:
            return f"${int(min_b):,} – ${int(max_b):,}"
        return f"Up to ${int(max_b):,}"
    return "Reputation only"


# ─── Main ─────────────────────────────────────────────────────────────────────

def run(domain: str, verbose: bool = False) -> Dict:
    """
    Main entry point for bug bounty lookup.
    Searches HackerOne and Bugcrowd for programs covering the target domain.
    """
    print(f"\n[*] Searching bug bounty programs for: {domain}")

    all_programs = []

    # Extract root domain for searching (e.g. sub.example.com → example.com)
    parts = domain.split(".")
    root_domain = ".".join(parts[-2:]) if len(parts) >= 2 else domain

    # HackerOne
    print("  [+] Searching HackerOne...")
    h1 = fetch_hackerone_programs(root_domain)
    if not h1:
        h1 = fetch_hackerone_directory(root_domain)
    all_programs.extend(h1)
    print(f"      Found {len(h1)} HackerOne program(s)")

    # Bugcrowd
    print("  [+] Searching Bugcrowd...")
    bc = fetch_bugcrowd_programs(root_domain)
    all_programs.extend(bc)
    print(f"      Found {len(bc)} Bugcrowd program(s)")

    # Check scope for each program
    all_programs = check_scope(domain, all_programs)

    # Categorize
    in_scope    = [p for p in all_programs if p["scope_status"] == "in_scope"]
    out_scope   = [p for p in all_programs if p["scope_status"] == "out_of_scope"]
    unknown     = [p for p in all_programs if p["scope_status"] == "unknown"]
    with_bounty = [p for p in in_scope if p.get("offers_bounty")]

    if verbose:
        for p in all_programs:
            status_icon = {"in_scope": "✓", "out_of_scope": "✗", "unknown": "?"}.get(
                p["scope_status"], "?"
            )
            bounty = format_bounty(p.get("min_bounty"), p.get("max_bounty"))
            print(f"      [{status_icon}] [{p['platform']}] {p['name']} — {bounty}")

    print(f"\n  [✓] Bug bounty lookup complete:")
    print(f"      Total programs  : {len(all_programs)}")
    print(f"      In scope        : {len(in_scope)}")
    print(f"      With bounty     : {len(with_bounty)}")
    print(f"      Out of scope    : {len(out_scope)}")

    if in_scope:
        print(f"\n  [!] TARGET IS IN SCOPE FOR BUG BOUNTY:")
        for p in in_scope:
            bounty = format_bounty(p.get("min_bounty"), p.get("max_bounty"))
            print(f"      → [{p['platform']}] {p['name']} | {bounty} | {p['url']}")

    return {
        "domain": domain,
        "total_programs": len(all_programs),
        "in_scope_count": len(in_scope),
        "out_of_scope_count": len(out_scope),
        "with_bounty_count": len(with_bounty),
        "in_scope": in_scope,
        "out_of_scope": out_scope,
        "unknown": unknown,
        "all_programs": all_programs,
    }
