"""
ReconAI - GitHub Secret & Leak Scanner Module
Searches GitHub for exposed secrets, API keys, credentials, and sensitive files.
Shows actual matched content, line numbers, file previews and direct links.
"""

import re
import requests
import time
import sys
from typing import List, Dict, Optional
from config.settings import GITHUB_TOKEN

# Regex patterns for common secrets
SECRET_PATTERNS = {
    "AWS Access Key":         r"AKIA[0-9A-Z]{16}",
    "AWS Secret Key":         r"(?i)aws.{0,20}secret.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]",
    "GitHub Token":           r"ghp_[a-zA-Z0-9]{36}|github_pat_[a-zA-Z0-9_]{82}",
    "Google API Key":         r"AIza[0-9A-Za-z\-_]{35}",
    "Google OAuth":           r"[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com",
    "Stripe Secret Key":      r"sk_live_[0-9a-zA-Z]{24}",
    "Stripe Publishable Key": r"pk_live_[0-9a-zA-Z]{24}",
    "Slack Token":            r"xox[baprs]-[0-9a-zA-Z]{10,48}",
    "Slack Webhook":          r"https://hooks\.slack\.com/services/[A-Z0-9/]+",
    "Twilio API Key":         r"SK[0-9a-fA-F]{32}",
    "SendGrid API Key":       r"SG\.[a-zA-Z0-9\-_]{22}\.[a-zA-Z0-9\-_]{43}",
    "Mailgun API Key":        r"key-[0-9a-zA-Z]{32}",
    "Firebase URL":           r"https://[a-z0-9-]+\.firebaseio\.com",
    "Firebase Key":           r"AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}",
    "RSA Private Key":        r"-----BEGIN RSA PRIVATE KEY-----",
    "EC Private Key":         r"-----BEGIN EC PRIVATE KEY-----",
    "PGP Private Key":        r"-----BEGIN PGP PRIVATE KEY BLOCK-----",
    "Generic Password":       r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"][^'\"]{8,}['\"]",
    "Generic Secret":         r"(?i)(secret|token|api_key|apikey)\s*[=:]\s*['\"][^'\"]{8,}['\"]",
    "Database URL":           r"(?i)(mysql|postgresql|mongodb|redis)://[^\s\"']+",
    "JWT Token":              r"eyJ[A-Za-z0-9_/+\-]{20,}\.[A-Za-z0-9_/+\-]{20,}\.[A-Za-z0-9_/+\-]{20,}",
    "Basic Auth in URL":      r"https?://[a-zA-Z0-9_-]+:[a-zA-Z0-9_@!#%&*]{4,}@",
    "Private Key Generic":    r"-----BEGIN [A-Z ]+ PRIVATE KEY-----",
    "NPM Token":              r"npm_[A-Za-z0-9]{36}",
    "Heroku API Key":         r"(?i)heroku.{0,20}['\"][0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}['\"]",
    "Bearer Token":           r"(?i)bearer\s+[a-zA-Z0-9\-_\.]{20,}",
    "Authorization Header":   r"(?i)authorization['\"]?\s*[=:]\s*['\"]?[a-zA-Z0-9\-_\. ]{20,}",
    "Private IP Leaked":      r"(?:10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.)\d+\.\d+",
    "Internal URL":           r"(?i)https?://(?:internal|intranet|corp|private|local)\.[a-z0-9\-\.]+",
}

SEARCH_QUERIES = [
    '"{domain}" password',
    '"{domain}" api_key',
    '"{domain}" secret',
    '"{domain}" token',
    '"{domain}" BEGIN RSA PRIVATE KEY',
    '"{domain}" credentials',
    '"{domain}" aws_access_key',
    '"{domain}" database_url',
    'filename:.env "{domain}"',
    'filename:config.php "{domain}"',
    'filename:settings.py "{domain}" SECRET_KEY',
    'filename:credentials "{domain}"',
    'filename:id_rsa "{domain}"',
    'filename:.npmrc "{domain}"',
    'filename:docker-compose.yml "{domain}"',
    'filename:Dockerfile "{domain}"',
    'org:{org} password',
    'org:{org} api_key',
    'org:{org} secret',
    'org:{org} filename:.env',
]


def build_headers() -> Dict:
    headers = {
        "Accept": "application/vnd.github.v3.text-match+json",
        "User-Agent": "ReconAI/1.0",
    }
    if GITHUB_TOKEN:
        headers["Authorization"] = f"token {GITHUB_TOKEN}"
    return headers


def search_github_code(query: str) -> List[Dict]:
    """Execute a GitHub code search, return enriched results with text matches."""
    results = []
    try:
        url = "https://api.github.com/search/code"
        params = {"q": query, "per_page": 10}
        resp = requests.get(url, headers=build_headers(), params=params, timeout=15)

        if resp.status_code == 403:
            reset_time = int(resp.headers.get("X-RateLimit-Reset", time.time() + 60))
            wait = max(0, reset_time - time.time()) + 2
            print(f"  [!] GitHub rate limit hit. Waiting {wait:.0f}s...")
            time.sleep(min(wait, 60))
            # Retry once
            resp = requests.get(url, headers=build_headers(), params=params, timeout=15)

        if resp.status_code == 422 or resp.status_code == 403:
            return results

        if resp.status_code == 200:
            data = resp.json()
            for item in data.get("items", []):
                repo_data = item.get("repository", {})
                result = {
                    "repo":         repo_data.get("full_name", ""),
                    "repo_url":     repo_data.get("html_url", ""),
                    "repo_desc":    repo_data.get("description", "") or "",
                    "repo_stars":   repo_data.get("stargazers_count", 0),
                    "file":         item.get("name", ""),
                    "path":         item.get("path", ""),
                    "url":          item.get("html_url", ""),
                    "raw_api_url":  item.get("url", ""),
                    "text_matches": [],
                }
                # Extract GitHub's highlighted text matches
                for match in item.get("text_matches", []):
                    fragment = match.get("fragment", "").strip()
                    if fragment:
                        result["text_matches"].append({
                            "fragment": fragment,
                            "matches":  [m.get("text", "") for m in match.get("matches", [])],
                        })
                results.append(result)

    except Exception as e:
        print(f"  [!] GitHub search error: {e}", file=sys.stderr)

    return results


def fetch_raw_content(raw_api_url: str) -> Optional[str]:
    """Fetch actual file content via GitHub API (returns decoded text)."""
    try:
        resp = requests.get(
            raw_api_url,
            headers={**build_headers(), "Accept": "application/vnd.github.v3.raw"},
            timeout=10
        )
        if resp.status_code == 200:
            return resp.text[:8000]  # Cap at 8KB
    except Exception:
        pass
    return None


def scan_content_for_secrets(content: str) -> List[Dict]:
    """Scan file content with all secret patterns, return detailed matches."""
    found = []
    lines = content.split("\n")

    for secret_name, pattern in SECRET_PATTERNS.items():
        try:
            for line_num, line in enumerate(lines, 1):
                matches = re.findall(pattern, line)
                for match in matches:
                    match_str = match if isinstance(match, str) else " ".join(match)
                    # Build context: the matched line + 1 line above/below
                    ctx_start = max(0, line_num - 2)
                    ctx_end   = min(len(lines), line_num + 1)
                    context   = "\n".join(
                        f"  {ctx_start + i + 1}: {l}"
                        for i, l in enumerate(lines[ctx_start:ctx_end])
                    )
                    found.append({
                        "type":          secret_name,
                        "severity":      _get_severity(secret_name),
                        "line":          line_num,
                        "raw_value":     match_str,
                        "redacted":      _redact(match_str),
                        "line_content":  line.strip()[:200],
                        "context":       context,
                    })
        except re.error:
            continue

    return found


def _redact(value: str) -> str:
    if len(value) <= 8:
        return "***"
    visible = max(4, len(value) // 6)
    return value[:visible] + "..." + value[-visible:]


def _get_severity(secret_type: str) -> str:
    critical = [
        "AWS Access Key", "AWS Secret Key", "RSA Private Key",
        "EC Private Key", "PGP Private Key", "Private Key Generic",
        "GitHub Token", "Stripe Secret Key",
    ]
    high = [
        "Google API Key", "Slack Token", "Firebase Key",
        "SendGrid API Key", "Database URL", "Basic Auth in URL",
        "NPM Token", "Heroku API Key", "Bearer Token",
    ]
    if secret_type in critical:
        return "CRITICAL"
    if secret_type in high:
        return "HIGH"
    return "MEDIUM"


def run(domain: str, org: str = None, verbose: bool = False) -> Dict:
    """
    Main entry point. Searches GitHub, fetches file content,
    and returns detailed findings with matched lines and context.
    """
    print(f"\n[*] Starting GitHub secret scan for: {domain}")

    if not GITHUB_TOKEN:
        print("  [!] No GITHUB_TOKEN — running unauthenticated (very rate limited)")

    if not org:
        org = domain.split(".")[0]

    all_findings  = []
    scanned_files = set()
    queries_run   = 0

    for query_template in SEARCH_QUERIES:
        query = query_template.format(domain=domain, org=org)
        if verbose:
            print(f"  [+] Query: {query}")

        results = search_github_code(query)
        queries_run += 1

        for result in results:
            file_key = f"{result['repo']}/{result['path']}"
            if file_key in scanned_files:
                continue
            scanned_files.add(file_key)

            # Fetch actual file content
            content = fetch_raw_content(result["raw_api_url"])

            secrets = []
            file_preview = ""

            if content:
                secrets = scan_content_for_secrets(content)
                # Store first 20 lines as preview
                preview_lines = content.split("\n")[:20]
                file_preview  = "\n".join(f"{i+1}: {l}" for i, l in enumerate(preview_lines))

            # Include result if: secrets found OR GitHub's own text matches suggest something sensitive
            github_matches = result.get("text_matches", [])
            has_interesting_match = any(
                any(kw in frag.get("fragment", "").lower()
                    for kw in ["password", "secret", "key", "token", "credential", "auth"])
                for frag in github_matches
            )

            if secrets or has_interesting_match:
                sev_score = {"CRITICAL": 3, "HIGH": 2, "MEDIUM": 1}
                highest_sev = max(
                    secrets,
                    key=lambda s: sev_score.get(s["severity"], 0),
                    default=None
                )

                finding = {
                    **result,
                    "secrets":          secrets,
                    "file_preview":     file_preview,
                    "highest_severity": highest_sev["severity"] if highest_sev else "MEDIUM",
                    "secret_count":     len(secrets),
                }
                all_findings.append(finding)

                # Print detailed terminal output
                sev_label = finding["highest_severity"]
                color = {
                    "CRITICAL": "\033[91m",
                    "HIGH":     "\033[93m",
                    "MEDIUM":   "\033[33m",
                }.get(sev_label, "")
                reset = "\033[0m"

                print(f"\n  {color}[{sev_label}]{reset} LEAK: {result['repo']}/{result['file']}")
                print(f"         URL    : {result['url']}")
                print(f"         Secrets: {len(secrets)}")

                for s in secrets[:5]:
                    print(f"         → [{s['severity']}] {s['type']} on line {s['line']}")
                    print(f"           Value  : {s['redacted']}")
                    print(f"           Context: {s['line_content'][:120]}")

                if not secrets and github_matches:
                    print(f"         → GitHub match snippet:")
                    for gm in github_matches[:2]:
                        print(f"           {gm['fragment'][:150]}")

        time.sleep(0.5)

    critical = sum(1 for f in all_findings if f.get("highest_severity") == "CRITICAL")
    high     = sum(1 for f in all_findings if f.get("highest_severity") == "HIGH")
    medium   = sum(1 for f in all_findings if f.get("highest_severity") == "MEDIUM")

    print(f"\n  [✓] GitHub scan complete:")
    print(f"      Queries run     : {queries_run}")
    print(f"      Files scanned   : {len(scanned_files)}")
    print(f"      Leaks found     : {len(all_findings)}")
    print(f"      Critical        : \033[91m{critical}\033[0m")
    print(f"      High            : \033[93m{high}\033[0m")
    print(f"      Medium          : \033[33m{medium}\033[0m")

    return {
        "domain":       domain,
        "org":          org,
        "total_leaks":  len(all_findings),
        "files_scanned":len(scanned_files),
        "critical":     critical,
        "high":         high,
        "medium":       medium,
        "findings":     all_findings,
    }
