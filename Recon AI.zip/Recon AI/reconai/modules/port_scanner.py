"""
ReconAI - Port & Service Fingerprinting Module
Performs fast TCP connect scans with banner grabbing and service detection.
"""

import socket
import ssl
import concurrent.futures
import sys
from typing import List, Dict, Optional
from config.settings import PORT_SCAN_TIMEOUT, MAX_THREADS, COMMON_PORTS, CRITICAL_SERVICES

# Service banner signatures for fingerprinting
SERVICE_SIGNATURES = {
    "SSH":           ["SSH-", "OpenSSH"],
    "FTP":           ["220 ", "FTP", "FileZilla", "vsftpd", "ProFTPD"],
    "SMTP":          ["220 ", "ESMTP", "Postfix", "Sendmail", "Exchange"],
    "HTTP":          ["HTTP/", "html", "nginx", "Apache", "IIS", "server:"],
    "MySQL":         ["\x00\x00\x00\n", "mysql", "MariaDB"],
    "Redis":         ["+PONG", "-ERR", "Redis"],
    "MongoDB":       ["MongoDB", "mongod"],
    "Elasticsearch": ["elasticsearch", "lucene"],
    "Docker":        ["Docker", "docker"],
    "Kubernetes":    ["kubernetes", "k8s"],
    "VNC":           ["RFB "],
    "RDP":           ["\x03\x00"],
    "Telnet":        ["\xff\xfd", "\xff\xfb", "login:"],
}

# HTTP paths worth probing on web ports
INTERESTING_PATHS = [
    "/", "/admin", "/login", "/dashboard", "/api", "/api/v1",
    "/swagger", "/swagger-ui.html", "/api-docs", "/graphql",
    "/.git/config", "/.env", "/config.php", "/wp-login.php",
    "/phpmyadmin", "/phpinfo.php", "/.htaccess", "/robots.txt",
    "/sitemap.xml", "/actuator", "/actuator/health", "/actuator/env",
    "/metrics", "/health", "/status", "/_cat/indices",
]

WEB_PORTS = {80, 443, 8080, 8443, 8888, 8001, 8081, 8082, 9000, 9090, 9443}


def grab_banner(host: str, port: int, timeout: float = PORT_SCAN_TIMEOUT) -> Optional[str]:
    """Attempt to grab a service banner."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))

        # For SSL/TLS ports, wrap the socket
        if port in (443, 8443, 993, 995, 465):
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            sock = ctx.wrap_socket(sock, server_hostname=host)

        # Send a generic probe to elicit a banner
        try:
            if port in WEB_PORTS or port == 443:
                sock.send(f"GET / HTTP/1.0\r\nHost: {host}\r\n\r\n".encode())
            else:
                sock.send(b"\r\n")
        except Exception:
            pass

        banner = sock.recv(1024).decode("utf-8", errors="replace")
        sock.close()
        return banner.strip()
    except Exception:
        return None


def identify_service(port: int, banner: Optional[str]) -> str:
    """Identify service from port number and banner."""
    # First check known port mappings
    known = {
        21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
        80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB",
        993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 1521: "Oracle",
        3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC",
        6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt",
        9200: "Elasticsearch", 9300: "Elasticsearch-Transport",
        27017: "MongoDB", 2375: "Docker-API", 2376: "Docker-TLS",
        10250: "Kubelet", 10255: "Kubelet-ReadOnly", 6443: "Kubernetes-API",
    }
    service = known.get(port, "Unknown")

    # Refine using banner signatures
    if banner:
        for svc, signatures in SERVICE_SIGNATURES.items():
            for sig in signatures:
                if sig.lower() in banner.lower():
                    return svc

    return service


def probe_http(host: str, port: int) -> Dict:
    """Probe HTTP/HTTPS port for interesting findings."""
    findings = []
    protocol = "https" if port in (443, 8443) else "http"
    base_url = f"{protocol}://{host}:{port}"

    import requests
    requests.packages.urllib3.disable_warnings()

    for path in INTERESTING_PATHS[:10]:  # Check top 10 paths
        try:
            url = f"{base_url}{path}"
            resp = requests.get(
                url,
                timeout=PORT_SCAN_TIMEOUT,
                verify=False,
                allow_redirects=False,
                headers={"User-Agent": "ReconAI/1.0"}
            )
            if resp.status_code in (200, 201, 301, 302, 401, 403):
                finding = {
                    "path": path,
                    "status": resp.status_code,
                    "content_length": len(resp.content),
                    "server": resp.headers.get("Server", ""),
                    "interesting": False,
                }
                # Flag interesting findings
                if path in ("/.git/config", "/.env", "/phpinfo.php"):
                    finding["interesting"] = True
                    finding["severity"] = "HIGH"
                elif resp.status_code == 200 and path in ("/admin", "/dashboard", "/phpmyadmin"):
                    finding["interesting"] = True
                    finding["severity"] = "MEDIUM"
                elif resp.status_code == 200 and path in ("/actuator/env", "/_cat/indices"):
                    finding["interesting"] = True
                    finding["severity"] = "HIGH"

                findings.append(finding)
        except Exception:
            continue

    return {"url": base_url, "paths": findings}


def scan_port(host: str, port: int) -> Optional[Dict]:
    """
    Scan a single port. Returns a result dict if open, None if closed.
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(PORT_SCAN_TIMEOUT)
        result = sock.connect_ex((host, port))
        sock.close()

        if result == 0:
            # Port is open — grab banner and identify service
            banner = grab_banner(host, port)
            service = identify_service(port, banner)
            is_critical = port in CRITICAL_SERVICES

            port_result = {
                "port": port,
                "state": "open",
                "service": service,
                "banner": banner[:200] if banner else None,
                "critical": is_critical,
                "risk_note": CRITICAL_SERVICES.get(port, ""),
            }

            # Extra HTTP probing for web ports
            if port in WEB_PORTS:
                port_result["http_probe"] = probe_http(host, port)

            return port_result

    except Exception:
        pass
    return None


def run(targets: List[str], ports: List[int] = None, verbose: bool = False) -> Dict:
    """
    Main entry point for port scanning.
    targets: list of hostnames/IPs to scan
    ports: list of ports (defaults to COMMON_PORTS)
    """
    if ports is None:
        ports = COMMON_PORTS

    print(f"\n[*] Starting port scan on {len(targets)} host(s), {len(ports)} ports each")
    all_results = {}

    for target in targets:
        print(f"  [+] Scanning {target}...")
        open_ports = []
        critical_ports = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            futures = {
                executor.submit(scan_port, target, port): port
                for port in ports
            }
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    open_ports.append(result)
                    if result["critical"]:
                        critical_ports.append(result)
                    if verbose:
                        flag = "[CRITICAL]" if result["critical"] else "[open]"
                        print(f"      {flag} {result['port']}/{result['service']}")

        # Sort by port number
        open_ports.sort(key=lambda x: x["port"])

        all_results[target] = {
            "host": target,
            "open_ports": open_ports,
            "total_open": len(open_ports),
            "critical_count": len(critical_ports),
            "critical_ports": critical_ports,
        }

        print(f"      Open: {len(open_ports)} | Critical: {len(critical_ports)}")

    print(f"\n  [✓] Port scanning complete")
    return all_results
