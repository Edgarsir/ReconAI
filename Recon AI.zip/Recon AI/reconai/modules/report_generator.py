"""
ReconAI - HTML Report Generator
Produces a professional, self-contained HTML security report
from all scan results.
"""

import json
import os
from datetime import datetime
from typing import Dict


RISK_COLORS = {
    "CRITICAL": "#e74c3c",
    "HIGH":     "#e67e22",
    "MEDIUM":   "#f39c12",
    "LOW":      "#27ae60",
    "UNKNOWN":  "#95a5a6",
}

RISK_BADGES = {
    "CRITICAL": '<span class="badge critical">CRITICAL</span>',
    "HIGH":     '<span class="badge high">HIGH</span>',
    "MEDIUM":   '<span class="badge medium">MEDIUM</span>',
    "LOW":      '<span class="badge low">LOW</span>',
}


def _badge(severity: str) -> str:
    return RISK_BADGES.get(severity.upper(), RISK_BADGES["LOW"])


def _score_to_risk(score: int) -> str:
    if score >= 9: return "CRITICAL"
    if score >= 7: return "HIGH"
    if score >= 4: return "MEDIUM"
    return "LOW"


def _escape(text: str) -> str:
    if not text:
        return ""
    return (str(text)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))


# ─── Section renderers ────────────────────────────────────────────────────────

def render_summary_cards(analysis: Dict, subdomain_data: Dict,
                          port_data: Dict, github_data: Dict,
                          wayback_data: Dict, shodan_data: Dict,
                          bugbounty_data: Dict) -> str:
    total_subdomains = subdomain_data.get("live_count", 0)
    total_open_ports = sum(h.get("total_open", 0) for h in port_data.values())
    total_leaks      = github_data.get("total_leaks", 0)
    total_alive      = wayback_data.get("alive_count", 0)
    total_vulns      = shodan_data.get("total_vulns", 0)
    bb_in_scope      = bugbounty_data.get("in_scope_count", 0)
    overall          = analysis.get("overall_risk", "UNKNOWN")
    color            = RISK_COLORS.get(overall, "#95a5a6")

    bb_color = "#27ae60" if bb_in_scope > 0 else "#e74c3c"
    bb_label = f"{bb_in_scope} In Scope" if bb_in_scope > 0 else "Not In Scope"

    return f"""
    <div class="summary-grid">
        <div class="card" style="border-left: 5px solid {color};">
            <div class="card-number" style="color:{color}">{overall}</div>
            <div class="card-label">Overall Risk</div>
        </div>
        <div class="card">
            <div class="card-number critical-text">{analysis.get('critical_count', 0)}</div>
            <div class="card-label">Critical Findings</div>
        </div>
        <div class="card">
            <div class="card-number" style="color:{bb_color}">{bb_label}</div>
            <div class="card-label">Bug Bounty Scope</div>
        </div>
        <div class="card">
            <div class="card-number">{total_subdomains}</div>
            <div class="card-label">Live Subdomains</div>
        </div>
        <div class="card">
            <div class="card-number">{total_open_ports}</div>
            <div class="card-label">Open Ports</div>
        </div>
        <div class="card">
            <div class="card-number" style="color:#e74c3c">{total_leaks}</div>
            <div class="card-label">GitHub Leaks</div>
        </div>
        <div class="card">
            <div class="card-number">{total_alive}</div>
            <div class="card-label">Wayback Endpoints</div>
        </div>
        <div class="card">
            <div class="card-number">{total_vulns}</div>
            <div class="card-label">Shodan CVEs</div>
        </div>
    </div>
    """


def render_top_findings(analysis: Dict) -> str:
    findings = analysis.get("top_findings", [])
    if not findings:
        return "<p>No significant findings.</p>"

    rows = ""
    for f in findings:
        risk       = _score_to_risk(f.get("risk_score", 0))
        notes_html = "<br>".join(_escape(n) for n in f.get("notes", [])[:2])
        url        = f.get("url", "")
        target     = _escape(f.get("target", ""))
        if url:
            target = f'<a href="{_escape(url)}" target="_blank">{target}</a>'
        rows += f"""
        <tr>
            <td>{_badge(risk)}</td>
            <td><code>{_escape(f.get('type',''))}</code></td>
            <td>{target}</td>
            <td class="notes-cell">{notes_html}</td>
            <td class="score-cell">{f.get('risk_score', 0)}/10</td>
        </tr>"""

    return f"""
    <table class="findings-table">
        <thead>
            <tr><th>Severity</th><th>Type</th><th>Target</th><th>Notes</th><th>Score</th></tr>
        </thead>
        <tbody>{rows}</tbody>
    </table>"""


def render_bugbounty(bugbounty_data: Dict) -> str:
    """Render bug bounty programs section."""
    programs = bugbounty_data.get("all_programs", [])
    if not programs:
        return """<div class="info-box">
            No bug bounty programs found on HackerOne or Bugcrowd for this domain.<br>
            Always ensure you have explicit written permission before testing.
        </div>"""

    in_scope  = [p for p in programs if p.get("scope_status") == "in_scope"]
    out_scope = [p for p in programs if p.get("scope_status") == "out_of_scope"]

    if in_scope:
        banner = f'<div class="bb-banner in-scope">✅ Target is IN SCOPE on {len(in_scope)} bug bounty program(s). Happy hunting!</div>'
    elif out_scope:
        banner = f'<div class="bb-banner out-scope">⛔ Target appears OUT OF SCOPE on known programs. Proceed only with explicit written permission.</div>'
    else:
        banner = '<div class="bb-banner unknown-scope">⚠️ Scope status unknown. Verify manually before testing.</div>'

    def _program_card(p):
        scope_status  = p.get("scope_status", "unknown")
        scope_color   = {"in_scope": "#27ae60", "out_of_scope": "#e74c3c", "unknown": "#f39c12"}.get(scope_status, "#95a5a6")
        scope_label   = {"in_scope": "IN SCOPE", "out_of_scope": "OUT OF SCOPE", "unknown": "UNKNOWN"}.get(scope_status)
        platform_color = "#1f6feb" if p.get("platform") == "HackerOne" else "#e05832"

        min_b = p.get("min_bounty")
        max_b = p.get("max_bounty")
        if max_b and int(max_b) > 0:
            bounty_str   = f"${int(min_b):,} – ${int(max_b):,}" if min_b and int(min_b) > 0 else f"Up to ${int(max_b):,}"
            bounty_color = "#27ae60"
        else:
            bounty_str   = "Reputation only"
            bounty_color = "#8b949e"

        matched  = ", ".join(_escape(s) for s in p.get("matched_scope", [])[:3])
        max_sev  = p.get("max_severity") or ""
        sub_state = p.get("submission_state", "open")

        scope_rows = ""
        for item in p.get("in_scope", [])[:8]:
            identifier = _escape(item.get("asset_identifier", ""))
            asset_type = _escape(item.get("asset_type", ""))
            eligible   = "✓" if item.get("eligible_for_bounty") else "–"
            scope_rows += f"<tr><td><code>{identifier}</code></td><td>{asset_type}</td><td>{eligible}</td></tr>"

        scope_table = f"""
        <table class="findings-table" style="margin-top:10px">
            <thead><tr><th>Asset</th><th>Type</th><th>Bounty Eligible</th></tr></thead>
            <tbody>{scope_rows}</tbody>
        </table>""" if scope_rows else ""

        return f"""
        <div class="bb-card">
            <div class="bb-card-header">
                <span class="bb-tag" style="background:{platform_color}22;color:{platform_color};border:1px solid {platform_color}44">
                    {_escape(p.get('platform',''))}
                </span>
                <strong style="color:#f0f6fc">{_escape(p.get('name',''))}</strong>
                <span class="bb-tag" style="background:{scope_color}22;color:{scope_color};border:1px solid {scope_color}44;margin-left:8px">
                    {scope_label}
                </span>
                <span style="color:{bounty_color};font-weight:700;margin-left:auto">{bounty_str}</span>
            </div>
            <div class="bb-card-meta">
                <span>Submission: <strong>{_escape(sub_state)}</strong></span>
                {f'<span>Max Severity: <strong>{_escape(max_sev)}</strong></span>' if max_sev else ''}
                {f'<span>Matched: <code>{matched}</code></span>' if matched else ''}
                <a href="{_escape(p.get('url',''))}" target="_blank">View Program →</a>
            </div>
            {scope_table}
        </div>"""

    ordered = in_scope + [p for p in programs if p.get("scope_status") == "unknown"] + out_scope
    cards = "".join(_program_card(p) for p in ordered)
    return banner + cards


def render_subdomains(subdomain_data: Dict) -> str:
    subs = subdomain_data.get("subdomains", [])
    if not subs:
        return "<p>No live subdomains found.</p>"

    rows = ""
    for s in subs[:50]:
        takeover = '<span class="badge critical">TAKEOVER RISK</span>' if s.get("takeover_risk") else ""
        ips      = ", ".join(s.get("ips", []))
        cname    = _escape(s.get("cname", "") or "")
        cdn      = _escape(s.get("cdn", "") or "")
        status   = s.get("http_status", "")
        title    = _escape(s.get("title", "") or "")

        status_badge = ""
        if status:
            color = "#27ae60" if status == 200 else "#f39c12" if status in (301,302) else "#e74c3c"
            status_badge = f'<span style="background:{color}22;color:{color};border:1px solid {color}44;padding:1px 6px;border-radius:3px;font-size:0.75rem">{status}</span>'

        rows += f"""
        <tr>
            <td><strong>{_escape(s['subdomain'])}</strong> {takeover}</td>
            <td>{status_badge}</td>
            <td>{_escape(ips)}</td>
            <td>{cdn}</td>
            <td>{title[:60]}</td>
            <td>{cname}</td>
        </tr>"""

    return f"""
    <table class="findings-table">
        <thead><tr><th>Subdomain</th><th>Status</th><th>IPs</th><th>CDN</th><th>Page Title</th><th>CNAME</th></tr></thead>
        <tbody>{rows}</tbody>
    </table>
    <p class="note">Showing top 50 of {len(subs)} live subdomains</p>"""


def render_ports(port_data: Dict) -> str:
    if not port_data:
        return "<p>No port data available.</p>"

    html = ""
    for host, data in port_data.items():
        open_ports = data.get("open_ports", [])
        if not open_ports:
            continue
        rows = ""
        for p in open_ports:
            risk = "CRITICAL" if p["port"] in (2375, 3389, 5900, 23, 10250, 9200, 27017, 6379) else \
                   "HIGH" if p.get("critical") else "LOW"
            rows += f"""
            <tr>
                <td>{p['port']}</td>
                <td>{_escape(p.get('service',''))}</td>
                <td>{_badge(risk)}</td>
                <td><code class="banner">{_escape((p.get('banner') or '')[:80])}</code></td>
                <td>{_escape(p.get('risk_note',''))}</td>
            </tr>"""

        html += f"""
        <h3>Host: {_escape(host)} <small>({data.get('total_open',0)} open, {data.get('critical_count',0)} critical)</small></h3>
        <table class="findings-table">
            <thead><tr><th>Port</th><th>Service</th><th>Risk</th><th>Banner</th><th>Note</th></tr></thead>
            <tbody>{rows}</tbody>
        </table>"""

    return html or "<p>No open ports found.</p>"


def render_github(github_data: Dict) -> str:
    findings = github_data.get("findings", [])
    if not findings:
        return "<p>No GitHub leaks found.</p>"

    html = f'<div class="alert">⚠️ Immediately revoke all exposed credentials listed below!</div>'

    for f in findings:
        sev         = f.get("highest_severity", "MEDIUM")
        secrets     = f.get("secrets", [])
        text_matches = f.get("text_matches", [])
        file_preview = f.get("file_preview", "")
        repo_desc    = _escape(f.get("repo_desc", ""))

        # Secret rows
        secret_rows = ""
        for s in secrets[:10]:
            secret_rows += f"""
            <tr>
                <td>{_badge(s.get('severity','MEDIUM'))}</td>
                <td><strong>{_escape(s.get('type',''))}</strong></td>
                <td>Line {s.get('line','?')}</td>
                <td><code>{_escape(s.get('redacted','***'))}</code></td>
                <td><code class="banner">{_escape(s.get('line_content','')[:100])}</code></td>
            </tr>"""

        secret_table = f"""
        <table class="findings-table" style="margin-top:10px">
            <thead><tr><th>Severity</th><th>Type</th><th>Line</th><th>Value</th><th>Context</th></tr></thead>
            <tbody>{secret_rows}</tbody>
        </table>""" if secret_rows else ""

        # GitHub text match fragments
        match_html = ""
        if text_matches and not secrets:
            match_html = "<div style='margin-top:10px'><strong>GitHub matched fragments:</strong><br>"
            for tm in text_matches[:3]:
                match_html += f"<pre class='code-block'>{_escape(tm.get('fragment','')[:300])}</pre>"
            match_html += "</div>"

        # File preview (first 20 lines)
        preview_html = ""
        if file_preview:
            preview_html = f"""
            <details style="margin-top:10px">
                <summary style="cursor:pointer;color:#58a6ff">📄 File preview (first 20 lines)</summary>
                <pre class="code-block">{_escape(file_preview[:2000])}</pre>
            </details>"""

        html += f"""
        <div class="bb-card" style="margin-bottom:16px">
            <div class="bb-card-header">
                {_badge(sev)}
                <a href="{_escape(f.get('repo_url',''))}" target="_blank" style="color:#f0f6fc;font-weight:700">{_escape(f.get('repo',''))}</a>
                <span style="color:#8b949e;font-size:0.8rem">/ {_escape(f.get('file',''))}</span>
                <a href="{_escape(f.get('url',''))}" target="_blank" style="margin-left:auto;font-size:0.8rem">View on GitHub →</a>
            </div>
            <div class="bb-card-meta">
                {f'<span>{repo_desc[:100]}</span>' if repo_desc else ''}
                <span>Path: <code>{_escape(f.get('path',''))}</code></span>
                <span>{len(secrets)} secret(s) found</span>
            </div>
            {secret_table}
            {match_html}
            {preview_html}
        </div>"""

    return html


def render_wayback(wayback_data: Dict) -> str:
    findings = wayback_data.get("findings", [])
    if not findings:
        return "<p>No live historical endpoints found.</p>"

    rows = ""
    for f in findings[:30]:
        risk      = _score_to_risk(f.get("score", 0))
        sensitive = ", ".join(f.get("sensitive_content", [])[:3])
        rows += f"""
        <tr>
            <td>{_badge(risk)}</td>
            <td><a href="{_escape(f['url'])}" target="_blank">{_escape(f['url'][:80])}</a></td>
            <td>{f.get('current_status','')}</td>
            <td>{_escape(', '.join(f.get('reasons',[])[:2]))}</td>
            <td>{_escape(sensitive)}</td>
        </tr>"""

    return f"""
    <table class="findings-table">
        <thead><tr><th>Risk</th><th>URL</th><th>Status</th><th>Reason</th><th>Sensitive Keywords</th></tr></thead>
        <tbody>{rows}</tbody>
    </table>
    <p class="note">Showing top 30 of {len(findings)} alive endpoints</p>"""


def render_shodan(shodan_data: Dict) -> str:
    if shodan_data.get("demo"):
        return """<div class="info-box">
            <strong>Shodan integration disabled</strong><br>
            Set the <code>SHODAN_API_KEY</code> environment variable to enable Shodan vulnerability data.
        </div>"""

    hosts = shodan_data.get("hosts", [])
    if not hosts:
        return "<p>No Shodan data available.</p>"

    html = ""
    for host in hosts:
        vulns = host.get("critical_vulns", []) + host.get("vulnerabilities", [])
        if not vulns:
            continue
        rows = ""
        for v in vulns:
            rows += f"""
            <tr>
                <td>{_badge(v.get('severity','LOW'))}</td>
                <td><code>{_escape(v.get('cve',''))}</code> {_escape(v.get('name',''))}</td>
                <td>{v.get('cvss','N/A')}</td>
                <td>{_escape(v.get('summary','')[:120])}</td>
            </tr>"""
        html += f"""
        <h3>{_escape(host.get('ip',''))} — {_escape(host.get('org',''))} ({_escape(host.get('country',''))})</h3>
        <table class="findings-table">
            <thead><tr><th>Severity</th><th>CVE</th><th>CVSS</th><th>Summary</th></tr></thead>
            <tbody>{rows}</tbody>
        </table>"""

    return html or "<p>No vulnerabilities found in Shodan data.</p>"


def render_remediation(analysis: Dict) -> str:
    remediation = analysis.get("remediation", [])
    if not remediation:
        return "<p>No remediation items generated.</p>"

    html = ""
    for item in remediation:
        priority   = item.get("priority", "MEDIUM")
        steps_html = "".join(f"<li>{_escape(s)}</li>" for s in item.get("steps", []))
        html += f"""
        <div class="remediation-item">
            <h3>{_badge(priority)} {_escape(item.get('title',''))}</h3>
            <ol>{steps_html}</ol>
        </div>"""
    return html


# ─── Full HTML generation ─────────────────────────────────────────────────────

def generate_html(
    domain: str,
    analysis: Dict,
    subdomain_data: Dict,
    port_data: Dict,
    github_data: Dict,
    wayback_data: Dict,
    shodan_data: Dict,
    bugbounty_data: Dict,
    scan_duration: float = 0,
) -> str:
    timestamp     = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    overall       = analysis.get("overall_risk", "UNKNOWN")
    overall_color = RISK_COLORS.get(overall, "#95a5a6")
    ai_summary    = analysis.get("ai_summary", "")

    ai_section = ""
    if ai_summary:
        ai_section = f"""
        <section id="ai-analysis">
            <h2>🤖 AI Security Analysis</h2>
            <div class="ai-box">{_escape(ai_summary)}</div>
        </section>"""

    bb_in = bugbounty_data.get("in_scope_count", 0)
    bb_pay = bugbounty_data.get("with_bounty_count", 0)
    if bb_in > 0:
        bb_meta = f'🎯 <strong style="color:#27ae60">{bb_in} bug bounty program(s) in scope, {bb_pay} with bounty</strong>'
    else:
        bb_meta = ""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ReconAI Report — {_escape(domain)}</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0d1117; color: #c9d1d9; line-height: 1.6;
        }}
        header {{
            background: linear-gradient(135deg, #161b22, #21262d);
            padding: 40px; border-bottom: 1px solid #30363d;
        }}
        header h1 {{ font-size: 2rem; color: #f0f6fc; }}
        header h1 span {{ color: {overall_color}; }}
        header .meta {{ color: #8b949e; margin-top: 8px; font-size: 0.9rem; }}
        main {{ max-width: 1400px; margin: 0 auto; padding: 40px 20px; }}
        section {{ margin-bottom: 50px; }}
        h2 {{
            font-size: 1.4rem; color: #f0f6fc; padding-bottom: 10px;
            border-bottom: 1px solid #30363d; margin-bottom: 20px;
        }}
        h3 {{ color: #e6edf3; margin: 20px 0 10px; font-size: 1rem; }}
        .summary-grid {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px; margin-bottom: 30px;
        }}
        .card {{
            background: #161b22; border: 1px solid #30363d; border-radius: 8px;
            padding: 20px; text-align: center;
        }}
        .card-number {{ font-size: 1.6rem; font-weight: 700; color: #58a6ff; }}
        .card-label {{ font-size: 0.75rem; color: #8b949e; margin-top: 4px; }}
        .critical-text {{ color: #e74c3c !important; }}
        .badge {{
            display: inline-block; padding: 2px 8px; border-radius: 4px;
            font-size: 0.75rem; font-weight: 700; text-transform: uppercase;
        }}
        .badge.critical {{ background: #e74c3c22; color: #e74c3c; border: 1px solid #e74c3c44; }}
        .badge.high {{ background: #e67e2222; color: #e67e22; border: 1px solid #e67e2244; }}
        .badge.medium {{ background: #f39c1222; color: #f39c12; border: 1px solid #f39c1244; }}
        .badge.low {{ background: #27ae6022; color: #27ae60; border: 1px solid #27ae6044; }}
        .findings-table {{
            width: 100%; border-collapse: collapse; font-size: 0.875rem; margin-bottom: 20px;
        }}
        .findings-table th {{
            background: #161b22; color: #8b949e; text-align: left;
            padding: 10px 12px; border-bottom: 1px solid #30363d; font-weight: 600;
        }}
        .findings-table td {{
            padding: 10px 12px; border-bottom: 1px solid #21262d; vertical-align: top;
        }}
        .findings-table tr:hover td {{ background: #161b22; }}
        .findings-table a {{ color: #58a6ff; text-decoration: none; }}
        .findings-table a:hover {{ text-decoration: underline; }}
        code {{ background: #21262d; padding: 2px 6px; border-radius: 3px; font-size: 0.8rem; color: #79c0ff; }}
        .banner {{ font-size: 0.7rem; color: #8b949e; word-break: break-all; }}
        .notes-cell {{ max-width: 300px; font-size: 0.8rem; color: #8b949e; }}
        .score-cell {{ text-align: center; font-weight: 700; color: #e74c3c; }}
        .alert {{
            background: #e74c3c22; border: 1px solid #e74c3c44; border-radius: 6px;
            padding: 12px 16px; margin-bottom: 16px; color: #e74c3c; font-weight: 600;
        }}
        .info-box {{
            background: #161b22; border: 1px solid #30363d; border-radius: 6px;
            padding: 16px; color: #8b949e;
        }}
        .ai-box {{
            background: #161b22; border: 1px solid #1f6feb; border-radius: 8px;
            padding: 20px; color: #c9d1d9; white-space: pre-wrap; line-height: 1.8;
            border-left: 4px solid #1f6feb;
        }}
        .remediation-item {{
            background: #161b22; border: 1px solid #30363d; border-radius: 8px;
            padding: 20px; margin-bottom: 16px;
        }}
        .remediation-item ol {{ padding-left: 20px; margin-top: 10px; }}
        .remediation-item li {{ margin-bottom: 6px; color: #8b949e; }}
        .note {{ color: #8b949e; font-size: 0.8rem; margin-top: 8px; }}
        nav {{
            background: #161b22; border-bottom: 1px solid #30363d;
            padding: 0 40px; display: flex; flex-wrap: wrap; position: sticky; top: 0; z-index: 100;
        }}
        nav a {{
            color: #8b949e; text-decoration: none; padding: 14px 14px;
            font-size: 0.875rem; border-bottom: 2px solid transparent;
        }}
        nav a:hover {{ color: #f0f6fc; border-bottom-color: #58a6ff; }}
        /* Bug bounty styles */
        .bb-banner {{
            padding: 14px 18px; border-radius: 8px; margin-bottom: 20px;
            font-weight: 600; font-size: 1rem;
        }}
        .bb-banner.in-scope {{ background: #27ae6022; border: 1px solid #27ae6044; color: #27ae60; }}
        .bb-banner.out-scope {{ background: #e74c3c22; border: 1px solid #e74c3c44; color: #e74c3c; }}
        .bb-banner.unknown-scope {{ background: #f39c1222; border: 1px solid #f39c1244; color: #f39c12; }}
        .bb-card {{
            background: #161b22; border: 1px solid #30363d; border-radius: 8px;
            padding: 16px; margin-bottom: 12px;
        }}
        .bb-card-header {{
            display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
        }}
        .bb-card-meta {{
            display: flex; gap: 16px; margin-top: 10px; font-size: 0.8rem;
            color: #8b949e; flex-wrap: wrap; align-items: center;
        }}
        .bb-card-meta a {{ color: #58a6ff; text-decoration: none; margin-left: auto; }}
        .bb-card-meta a:hover {{ text-decoration: underline; }}
        .bb-tag {{
            display: inline-block; padding: 2px 8px; border-radius: 4px;
            font-size: 0.75rem; font-weight: 700;
        }}
        pre.code-block {{
            background: #0d1117; border: 1px solid #30363d; border-radius: 6px;
            padding: 12px; font-size: 0.75rem; color: #79c0ff;
            overflow-x: auto; white-space: pre-wrap; word-break: break-all;
            margin-top: 8px; max-height: 300px; overflow-y: auto;
        }}
        footer {{
            text-align: center; padding: 40px; color: #8b949e; font-size: 0.8rem;
            border-top: 1px solid #30363d; margin-top: 60px;
        }}
    </style>
</head>
<body>
<header>
    <h1>🔍 ReconAI — Attack Surface Report: <span>{_escape(domain)}</span></h1>
    <div class="meta">
        Generated: {timestamp} &nbsp;|&nbsp;
        Duration: {scan_duration:.1f}s &nbsp;|&nbsp;
        Risk: <strong style="color:{overall_color}">{overall}</strong> &nbsp;|&nbsp;
        Findings: {analysis.get('total_findings', 0)}
        {"&nbsp;|&nbsp; 🤖 AI-Enhanced" if analysis.get('ai_used') else ""}
        {f"&nbsp;|&nbsp; {bb_meta}" if bb_meta else ""}
    </div>
</header>

<nav>
    <a href="#summary">Summary</a>
    <a href="#top-findings">Top Findings</a>
    {"<a href='#ai-analysis'>AI Analysis</a>" if ai_summary else ""}
    <a href="#bugbounty">Bug Bounty</a>
    <a href="#subdomains">Subdomains</a>
    <a href="#ports">Ports</a>
    <a href="#github">GitHub Leaks</a>
    <a href="#wayback">Wayback</a>
    <a href="#shodan">Shodan</a>
    <a href="#remediation">Remediation</a>
</nav>

<main>
    <section id="summary">
        <h2>📊 Executive Summary</h2>
        {render_summary_cards(analysis, subdomain_data, port_data, github_data, wayback_data, shodan_data, bugbounty_data)}
    </section>

    <section id="top-findings">
        <h2>🎯 Top Findings (Prioritized by Risk)</h2>
        {render_top_findings(analysis)}
    </section>

    {ai_section}

    <section id="bugbounty">
        <h2>💰 Bug Bounty Programs</h2>
        <p style="color:#8b949e;margin-bottom:16px">
            Found {bugbounty_data.get('total_programs',0)} program(s) —
            {bugbounty_data.get('in_scope_count',0)} in scope,
            {bugbounty_data.get('with_bounty_count',0)} with bounty payout.
        </p>
        {render_bugbounty(bugbounty_data)}
    </section>

    <section id="subdomains">
        <h2>🌐 Subdomain Enumeration</h2>
        <p style="color:#8b949e;margin-bottom:16px">
            {subdomain_data.get('total_found',0)} discovered,
            {subdomain_data.get('live_count',0)} live,
            {subdomain_data.get('takeover_risks',0)} takeover risks.
        </p>
        {render_subdomains(subdomain_data)}
    </section>

    <section id="ports">
        <h2>🔌 Port & Service Fingerprinting</h2>
        {render_ports(port_data)}
    </section>

    <section id="github">
        <h2>🔑 GitHub Secret Scanning</h2>
        <p style="color:#8b949e;margin-bottom:16px">
            {github_data.get('total_leaks',0)} repositories with leaked credentials
            ({github_data.get('critical',0)} critical, {github_data.get('high',0)} high).
        </p>
        {render_github(github_data)}
    </section>

    <section id="wayback">
        <h2>⏰ Wayback Machine Endpoint Discovery</h2>
        <p style="color:#8b949e;margin-bottom:16px">
            {wayback_data.get('total_found',0)} historical URLs found,
            {wayback_data.get('alive_count',0)} still alive today.
        </p>
        {render_wayback(wayback_data)}
    </section>

    <section id="shodan">
        <h2>🔭 Shodan Intelligence</h2>
        <p style="color:#8b949e;margin-bottom:16px">
            {shodan_data.get('total_ips',0)} IPs analyzed,
            {shodan_data.get('total_vulns',0)} CVEs found
            ({shodan_data.get('critical_vulns',0)} critical).
        </p>
        {render_shodan(shodan_data)}
    </section>

    <section id="remediation">
        <h2>🛡️ Remediation Recommendations</h2>
        {render_remediation(analysis)}
    </section>
</main>

<footer>
    ReconAI v1.0 — For authorized security testing and bug bounty hunting only.
    Do not use against targets you don't own or have explicit written permission to test.
</footer>
</body>
</html>"""


# ─── Entry point ──────────────────────────────────────────────────────────────

def run(
    domain: str,
    analysis: Dict,
    subdomain_data: Dict,
    port_data: Dict,
    github_data: Dict,
    wayback_data: Dict,
    shodan_data: Dict,
    bugbounty_data: Dict = None,
    output_dir: str = "reports",
    scan_duration: float = 0,
) -> str:
    """Generate and save the HTML report. Returns the path to the saved file."""
    print(f"\n[*] Generating HTML report...")

    if bugbounty_data is None:
        bugbounty_data = {"total_programs": 0, "in_scope_count": 0,
                          "with_bounty_count": 0, "all_programs": []}

    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename  = f"{domain.replace('.', '_')}_{timestamp}.html"
    filepath  = os.path.join(output_dir, filename)

    html = generate_html(
        domain=domain,
        analysis=analysis,
        subdomain_data=subdomain_data,
        port_data=port_data,
        github_data=github_data,
        wayback_data=wayback_data,
        shodan_data=shodan_data,
        bugbounty_data=bugbounty_data,
        scan_duration=scan_duration,
    )

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html)

    # Raw JSON
    json_filename = f"{domain.replace('.', '_')}_{timestamp}.json"
    json_filepath = os.path.join(output_dir, json_filename)
    with open(json_filepath, "w", encoding="utf-8") as f:
        json.dump({
            "domain": domain, "timestamp": timestamp,
            "analysis": analysis, "subdomains": subdomain_data,
            "ports": port_data, "github": github_data,
            "wayback": wayback_data, "shodan": shodan_data,
            "bugbounty": bugbounty_data,
        }, f, indent=2, default=str)

    print(f"  [✓] Report saved: {filepath}")
    print(f"  [✓] Raw JSON saved: {json_filepath}")
    return filepath
