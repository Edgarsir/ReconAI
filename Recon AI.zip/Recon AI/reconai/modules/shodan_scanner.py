"""
ReconAI - Shodan Integration Module
Queries Shodan for exposed services, vulnerabilities, and threat intelligence
on target IPs/domains.
"""

import requests
import sys
from typing import List, Dict, Optional
from config.settings import SHODAN_API_KEY

SHODAN_BASE = "https://api.shodan.io"

# Known critical CVEs and their severity
CRITICAL_CVE_PATTERNS = {
    "CVE-2021-44228": ("Log4Shell", "CRITICAL"),
    "CVE-2021-26855": ("Exchange ProxyLogon", "CRITICAL"),
    "CVE-2020-1472":  ("Zerologon", "CRITICAL"),
    "CVE-2019-0708":  ("BlueKeep RDP", "CRITICAL"),
    "CVE-2017-0144":  ("EternalBlue/WannaCry", "CRITICAL"),
    "CVE-2021-34527": ("PrintNightmare", "HIGH"),
    "CVE-2022-30190": ("Follina MSDT", "HIGH"),
    "CVE-2021-21985": ("VMware vCenter", "CRITICAL"),
    "CVE-2022-22965": ("Spring4Shell", "CRITICAL"),
    "CVE-2023-44487": ("HTTP/2 Rapid Reset", "HIGH"),
}


def query_shodan_host(ip: str) -> Optional[Dict]:
    """Query Shodan for a specific IP address."""
    if not SHODAN_API_KEY:
        return None
    try:
        url = f"{SHODAN_BASE}/shodan/host/{ip}"
        params = {"key": SHODAN_API_KEY}
        resp = requests.get(url, params=params, timeout=15)

        if resp.status_code == 200:
            return resp.json()
        elif resp.status_code == 404:
            return {"ip_str": ip, "not_found": True}
        elif resp.status_code == 401:
            print("  [!] Shodan API key invalid or expired", file=sys.stderr)
            return None
    except Exception as e:
        print(f"  [!] Shodan query error for {ip}: {e}", file=sys.stderr)
    return None


def query_shodan_dns(domain: str) -> Optional[Dict]:
    """Resolve a domain to IPs via Shodan DNS resolve."""
    if not SHODAN_API_KEY:
        return None
    try:
        url = f"{SHODAN_BASE}/dns/resolve"
        params = {"key": SHODAN_API_KEY, "hostnames": domain}
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code == 200:
            return resp.json()
    except Exception as e:
        print(f"  [!] Shodan DNS resolve error: {e}", file=sys.stderr)
    return None


def search_shodan(query: str, limit: int = 20) -> List[Dict]:
    """Execute a Shodan search query."""
    if not SHODAN_API_KEY:
        return []
    results = []
    try:
        url = f"{SHODAN_BASE}/shodan/host/search"
        params = {
            "key": SHODAN_API_KEY,
            "query": query,
            "minify": True,
        }
        resp = requests.get(url, params=params, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            matches = data.get("matches", [])[:limit]
            for match in matches:
                results.append({
                    "ip": match.get("ip_str"),
                    "port": match.get("port"),
                    "org": match.get("org"),
                    "hostnames": match.get("hostnames", []),
                    "product": match.get("product", ""),
                    "version": match.get("version", ""),
                    "cpe": match.get("cpe23", []),
                    "vulns": list(match.get("vulns", {}).keys()),
                    "timestamp": match.get("timestamp"),
                    "data": match.get("data", "")[:200],
                })
    except Exception as e:
        print(f"  [!] Shodan search error: {e}", file=sys.stderr)
    return results


def parse_host_data(data: Dict) -> Dict:
    """Parse and enrich raw Shodan host data."""
    if not data or data.get("not_found"):
        return data or {}

    result = {
        "ip": data.get("ip_str"),
        "org": data.get("org", "Unknown"),
        "isp": data.get("isp", "Unknown"),
        "country": data.get("country_name", "Unknown"),
        "city": data.get("city", "Unknown"),
        "os": data.get("os"),
        "open_ports": data.get("ports", []),
        "hostnames": data.get("hostnames", []),
        "domains": data.get("domains", []),
        "tags": data.get("tags", []),
        "last_update": data.get("last_update"),
        "services": [],
        "vulnerabilities": [],
        "critical_vulns": [],
    }

    # Parse service banners
    for service in data.get("data", []):
        svc = {
            "port": service.get("port"),
            "transport": service.get("transport", "tcp"),
            "product": service.get("product", ""),
            "version": service.get("version", ""),
            "cpe": service.get("cpe23", []),
            "banner": service.get("data", "")[:300],
            "ssl": service.get("ssl", {}).get("cert", {}) != {},
        }
        result["services"].append(svc)

    # Parse vulnerabilities
    vulns = data.get("vulns", {})
    for cve_id, vuln_data in vulns.items():
        cvss = vuln_data.get("cvss", 0)
        vuln_entry = {
            "cve": cve_id,
            "cvss": cvss,
            "summary": vuln_data.get("summary", "")[:200],
            "severity": _cvss_to_severity(cvss),
        }

        # Check against known critical CVEs
        if cve_id in CRITICAL_CVE_PATTERNS:
            name, sev = CRITICAL_CVE_PATTERNS[cve_id]
            vuln_entry["name"] = name
            vuln_entry["severity"] = sev
            result["critical_vulns"].append(vuln_entry)
        else:
            result["vulnerabilities"].append(vuln_entry)

    return result


def _cvss_to_severity(cvss: float) -> str:
    """Convert CVSS score to severity label."""
    if cvss >= 9.0:
        return "CRITICAL"
    elif cvss >= 7.0:
        return "HIGH"
    elif cvss >= 4.0:
        return "MEDIUM"
    elif cvss > 0:
        return "LOW"
    return "UNKNOWN"


def simulate_shodan_results(domain: str) -> Dict:
    """
    Returns simulated Shodan-style data when no API key is provided.
    Used for demo/testing purposes only.
    """
    return {
        "domain": domain,
        "note": "No Shodan API key configured. Set SHODAN_API_KEY env variable for real results.",
        "demo": True,
        "total_ips": 0,
        "total_vulns": 0,
        "critical_vulns": 0,
        "hosts": [],
    }


def run(domain: str, ips: List[str] = None, verbose: bool = False) -> Dict:
    """
    Main entry point for Shodan scanning.
    domain: target domain
    ips: optional list of IPs to scan directly (from subdomain enumeration)
    """
    print(f"\n[*] Starting Shodan intelligence gathering for: {domain}")

    if not SHODAN_API_KEY:
        print("  [!] No SHODAN_API_KEY set — skipping Shodan (set env var to enable)")
        return simulate_shodan_results(domain)

    all_ips = set(ips) if ips else set()

    # Resolve domain IPs via Shodan
    print("  [+] Resolving domain IPs via Shodan...")
    dns_data = query_shodan_dns(domain)
    if dns_data:
        for hostname, ip in dns_data.items():
            if ip:
                all_ips.add(ip)

    # Search Shodan for domain references
    print(f"  [+] Searching Shodan for '{domain}'...")
    search_results = search_shodan(f'hostname:"{domain}"')
    for result in search_results:
        if result.get("ip"):
            all_ips.add(result["ip"])

    print(f"  [+] Found {len(all_ips)} unique IPs. Querying host data...")

    enriched_hosts = []
    total_vulns = 0
    total_critical = 0

    for ip in list(all_ips)[:20]:  # Cap at 20 IPs to avoid API quota abuse
        raw = query_shodan_host(ip)
        if raw:
            parsed = parse_host_data(raw)
            vuln_count = len(parsed.get("vulnerabilities", []))
            critical_count = len(parsed.get("critical_vulns", []))
            total_vulns += vuln_count
            total_critical += critical_count
            enriched_hosts.append(parsed)

            if verbose:
                print(f"      {ip}: {len(parsed.get('open_ports', []))} ports, "
                      f"{vuln_count} vulns ({critical_count} critical)")

    enriched_hosts.sort(
        key=lambda h: len(h.get("critical_vulns", [])) + len(h.get("vulnerabilities", [])),
        reverse=True
    )

    print(f"\n  [✓] Shodan scan complete:")
    print(f"      IPs analyzed    : {len(enriched_hosts)}")
    print(f"      Total vulns     : {total_vulns}")
    print(f"      Critical vulns  : {total_critical}")

    return {
        "domain": domain,
        "total_ips": len(enriched_hosts),
        "total_vulns": total_vulns,
        "critical_vulns": total_critical,
        "hosts": enriched_hosts,
    }
