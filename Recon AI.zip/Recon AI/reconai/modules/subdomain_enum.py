"""
ReconAI - Subdomain Enumeration Module
Sources: DNS brute force + Certificate Transparency (crt.sh) + DNSDumpster-style
"""

import dns.resolver
import requests
import re
import json
import concurrent.futures
import sys
from typing import Set, List, Dict
from config.settings import DNS_TIMEOUT, MAX_THREADS, MAX_SUBDOMAINS

# Built-in wordlist for DNS brute force
SUBDOMAIN_WORDLIST = [
    "www", "mail", "ftp", "localhost", "webmail", "smtp", "pop", "ns1", "ns2",
    "webdisk", "ns", "cpanel", "whm", "autodiscover", "autoconfig", "m", "imap",
    "test", "ns3", "vpn", "mail2", "new", "mysql", "old", "lists", "support",
    "mobile", "mx", "static", "docs", "beta", "shop", "api", "dev", "staging",
    "admin", "portal", "dashboard", "secure", "login", "app", "cloud", "remote",
    "cdn", "media", "images", "img", "video", "assets", "downloads", "files",
    "backup", "db", "database", "sql", "git", "gitlab", "github", "jira",
    "jenkins", "ci", "build", "deploy", "prod", "production", "uat", "qa",
    "internal", "intranet", "corp", "office", "employees", "hr", "finance",
    "monitor", "nagios", "zabbix", "grafana", "kibana", "elastic", "redis",
    "mongo", "kafka", "rabbitmq", "docker", "k8s", "kubernetes", "vault",
    "auth", "sso", "oauth", "ldap", "vpn2", "gateway", "proxy", "waf",
    "smtp2", "relay", "exchange", "owa", "webmail2", "crm", "erp", "wiki",
    "confluence", "sharepoint", "s3", "bucket", "storage", "archive", "log",
    "logs", "metrics", "stats", "status", "health", "ping", "demo", "sandbox",
    "preview", "review", "test2", "dev2", "api2", "api-dev", "api-staging",
    "v1", "v2", "v3", "graphql", "ws", "websocket", "socket", "live", "stream",
]


def cert_transparency_lookup(domain: str) -> Set[str]:
    """Query crt.sh certificate transparency logs for subdomains."""
    subdomains = set()
    try:
        url = f"https://crt.sh/?q=%.{domain}&output=json"
        resp = requests.get(url, timeout=15, headers={"User-Agent": "ReconAI/1.0"})
        if resp.status_code == 200:
            data = resp.json()
            for entry in data:
                name = entry.get("name_value", "")
                # Each entry may contain multiple names separated by newlines
                for n in name.split("\n"):
                    n = n.strip().lower()
                    # Remove wildcard prefix
                    if n.startswith("*."):
                        n = n[2:]
                    if n.endswith(f".{domain}") or n == domain:
                        subdomains.add(n)
    except Exception as e:
        print(f"  [!] crt.sh lookup failed: {e}", file=sys.stderr)
    return subdomains


def hackertarget_lookup(domain: str) -> Set[str]:
    """Query HackerTarget API for subdomains."""
    subdomains = set()
    try:
        url = f"https://api.hackertarget.com/hostsearch/?q={domain}"
        resp = requests.get(url, timeout=10, headers={"User-Agent": "ReconAI/1.0"})
        if resp.status_code == 200 and "error" not in resp.text.lower():
            for line in resp.text.strip().split("\n"):
                parts = line.split(",")
                if parts:
                    sub = parts[0].strip().lower()
                    if sub.endswith(f".{domain}") or sub == domain:
                        subdomains.add(sub)
    except Exception as e:
        print(f"  [!] HackerTarget lookup failed: {e}", file=sys.stderr)
    return subdomains


def alienvault_lookup(domain: str) -> Set[str]:
    """Query AlienVault OTX for subdomains."""
    subdomains = set()
    try:
        url = f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns"
        resp = requests.get(url, timeout=10, headers={"User-Agent": "ReconAI/1.0"})
        if resp.status_code == 200:
            data = resp.json()
            for record in data.get("passive_dns", []):
                hostname = record.get("hostname", "").lower()
                if hostname.endswith(f".{domain}") or hostname == domain:
                    subdomains.add(hostname)
    except Exception as e:
        print(f"  [!] AlienVault lookup failed: {e}", file=sys.stderr)
    return subdomains


def dns_resolve(subdomain: str) -> Dict:
    """Attempt to resolve a subdomain, return result dict."""
    result = {"subdomain": subdomain, "resolved": False, "ips": [], "cname": None}
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = DNS_TIMEOUT
        resolver.lifetime = DNS_TIMEOUT

        # Try A record
        try:
            answers = resolver.resolve(subdomain, "A")
            result["resolved"] = True
            result["ips"] = [str(r) for r in answers]
        except dns.resolver.NoAnswer:
            pass

        # Try CNAME if no A record
        if not result["resolved"]:
            try:
                answers = resolver.resolve(subdomain, "CNAME")
                result["resolved"] = True
                result["cname"] = str(answers[0].target)
            except Exception:
                pass

    except (dns.resolver.NXDOMAIN, dns.resolver.NoNameservers,
            dns.exception.Timeout, Exception):
        pass

    # HTTP fallback — catches CDN-protected domains that block DNS resolution
    if not result["resolved"]:
        result = _http_probe_fallback(subdomain, result)

    return result


def _http_probe_fallback(subdomain: str, result: Dict) -> Dict:
    """
    Try HTTP/HTTPS directly when DNS fails.
    CDN-protected subdomains (Cloudflare, Fastly, Akamai) often still
    respond to HTTP even when DNS resolution returns no IPs.
    """
    for protocol in ("https", "http"):
        try:
            resp = requests.get(
                f"{protocol}://{subdomain}",
                timeout=DNS_TIMEOUT,
                verify=False,
                allow_redirects=True,
                headers={"User-Agent": "ReconAI/1.0"},
            )
            if resp.status_code < 500:
                result["resolved"]    = True
                result["http_status"] = resp.status_code
                result["http_proto"]  = protocol
                result["server"]      = resp.headers.get("Server", "")
                result["title"]       = _extract_title(resp.text)
                result["cdn"]         = _detect_cdn(resp.headers)
                # Try to get IP from response headers (Cloudflare exposes CF-Ray)
                cf_ray = resp.headers.get("CF-Ray", "")
                if cf_ray:
                    result["cdn"] = "Cloudflare"
                break
        except Exception:
            continue
    return result


def _extract_title(html: str) -> str:
    """Extract page title from HTML."""
    match = re.search(r"<title[^>]*>([^<]{1,100})</title>", html, re.IGNORECASE)
    return match.group(1).strip() if match else ""


def _detect_cdn(headers: dict) -> str:
    """Detect CDN from response headers."""
    header_str = str(headers).lower()
    if "cloudflare" in header_str or "cf-ray" in str(headers):
        return "Cloudflare"
    if "fastly" in header_str:
        return "Fastly"
    if "akamai" in header_str:
        return "Akamai"
    if "awselb" in header_str or "cloudfront" in header_str:
        return "AWS CloudFront"
    if "x-cache" in header_str:
        return "CDN (generic)"
    return ""


def check_subdomain_takeover(result: Dict) -> bool:
    """
    Heuristic check for potential subdomain takeover.
    If CNAME points to a service that returns 404/NoSuchBucket etc.
    """
    takeover_signatures = [
        "NoSuchBucket", "no such bucket",
        "There is no app here",
        "herokucdn.com",
        "GitHub Pages",
        "Fastly error",
        "This page does not exist",
        "Repository not found",
        "The feed has not been found",
    ]
    if not result.get("cname"):
        return False
    try:
        resp = requests.get(
            f"http://{result['subdomain']}",
            timeout=5,
            allow_redirects=True,
            headers={"User-Agent": "ReconAI/1.0"}
        )
        body = resp.text[:2000]
        for sig in takeover_signatures:
            if sig.lower() in body.lower():
                return True
    except Exception:
        pass
    return False


def dns_bruteforce(domain: str, wordlist: List[str]) -> List[Dict]:
    """Brute force subdomains using wordlist with threading."""
    candidates = [f"{word}.{domain}" for word in wordlist]
    resolved = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = {executor.submit(dns_resolve, sub): sub for sub in candidates}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result["resolved"]:
                resolved.append(result)

    return resolved


def run(domain: str, verbose: bool = False) -> Dict:
    """
    Main entry point for subdomain enumeration.
    Returns structured results dict.
    """
    print(f"\n[*] Starting subdomain enumeration for: {domain}")
    all_subdomains = set()
    findings = []

    # Step 1: Passive recon from multiple sources
    print("  [+] Querying certificate transparency logs (crt.sh)...")
    ct_subs = cert_transparency_lookup(domain)
    all_subdomains.update(ct_subs)
    print(f"      Found {len(ct_subs)} subdomains via crt.sh")

    print("  [+] Querying HackerTarget...")
    ht_subs = hackertarget_lookup(domain)
    all_subdomains.update(ht_subs)
    print(f"      Found {len(ht_subs)} subdomains via HackerTarget")

    print("  [+] Querying AlienVault OTX...")
    av_subs = alienvault_lookup(domain)
    all_subdomains.update(av_subs)
    print(f"      Found {len(av_subs)} subdomains via AlienVault")

    # Step 2: DNS brute force
    print(f"  [+] DNS brute force ({len(SUBDOMAIN_WORDLIST)} words)...")
    brute_results = dns_bruteforce(domain, SUBDOMAIN_WORDLIST)
    for r in brute_results:
        all_subdomains.add(r["subdomain"])
    print(f"      Found {len(brute_results)} subdomains via brute force")

    # Step 3: Resolve all discovered subdomains
    print(f"  [+] Resolving {len(all_subdomains)} unique subdomains...")
    to_resolve = list(all_subdomains)[:MAX_SUBDOMAINS]

    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = {executor.submit(dns_resolve, sub): sub for sub in to_resolve}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result["resolved"]:
                findings.append(result)

    # Step 4: Check for subdomain takeover
    print(f"  [+] Checking {len(findings)} live subdomains for takeover opportunities...")
    for finding in findings:
        if finding.get("cname"):
            finding["takeover_risk"] = check_subdomain_takeover(finding)
        else:
            finding["takeover_risk"] = False

    takeover_count = sum(1 for f in findings if f.get("takeover_risk"))

    print(f"\n  [✓] Subdomain enumeration complete:")
    print(f"      Total discovered : {len(all_subdomains)}")
    print(f"      Live subdomains  : {len(findings)}")
    print(f"      Takeover risks   : {takeover_count}")

    if verbose:
        print(f"\n  Live subdomains:")
        for f in findings[:20]:
            cdn    = f.get("cdn", "")
            status = f.get("http_status", "")
            title  = f.get("title", "")
            ips    = ", ".join(f.get("ips", []))
            line   = f"      {f['subdomain']}"
            if ips:
                line += f"  →  {ips}"
            if status:
                line += f"  [{status}]"
            if cdn:
                line += f"  ({cdn})"
            if title:
                line += f'  "{title[:50]}"'
            print(line)

    return {
        "domain": domain,
        "total_found": len(all_subdomains),
        "live_count": len(findings),
        "takeover_risks": takeover_count,
        "subdomains": findings,
    }
