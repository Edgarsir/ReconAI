"""
ReconAI - Wayback Machine Dead Endpoint Discovery Module
Finds old/forgotten URLs from the Wayback Machine that may still be live
and could expose sensitive data or forgotten attack surface.
"""

import requests
import concurrent.futures
import re
from urllib.parse import urlparse
from typing import List, Dict, Set
from config.settings import WAYBACK_LIMIT, MAX_THREADS, PORT_SCAN_TIMEOUT

# Patterns that indicate an interesting/sensitive endpoint
SENSITIVE_PATTERNS = [
    r"admin", r"login", r"password", r"passwd", r"secret", r"key", r"token",
    r"api", r"debug", r"test", r"backup", r"bak", r"old", r"dev", r"staging",
    r"config", r"conf", r"cfg", r"env", r"setup", r"install", r"phpinfo",
    r"phpmyadmin", r"mysql", r"database", r"db", r"dump", r"export",
    r"upload", r"uploads", r"file", r"files", r"document", r"docs",
    r"log", r"logs", r"error", r"trace", r"debug", r"console",
    r"swagger", r"graphql", r"api-docs", r"openapi",
    r"\.git", r"\.svn", r"\.htaccess", r"\.env", r"web\.config",
    r"wp-admin", r"wp-login", r"xmlrpc",
    r"actuator", r"metrics", r"health", r"status",
]

# File extensions that are interesting
INTERESTING_EXTENSIONS = {
    ".php", ".asp", ".aspx", ".jsp", ".jspx", ".do", ".action",
    ".xml", ".json", ".yaml", ".yml", ".conf", ".config", ".ini",
    ".bak", ".backup", ".old", ".sql", ".db", ".sqlite",
    ".log", ".txt", ".csv", ".xls", ".xlsx", ".zip", ".tar", ".gz",
    ".key", ".pem", ".crt", ".cer", ".p12",
}

# Extensions to skip (images, fonts, etc.)
SKIP_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".woff",
    ".woff2", ".ttf", ".eot", ".mp4", ".mp3", ".avi", ".css",
}


def fetch_wayback_urls(domain: str, limit: int = WAYBACK_LIMIT) -> List[str]:
    """
    Fetch URLs from Wayback Machine CDX API.
    Returns a deduplicated list of URLs.
    """
    urls = []
    try:
        # CDX API - fetch unique URLs with status 200
        cdx_url = (
            f"http://web.archive.org/cdx/search/cdx"
            f"?url=*.{domain}/*"
            f"&output=json"
            f"&fl=original,statuscode,mimetype"
            f"&filter=statuscode:200"
            f"&collapse=urlkey"
            f"&limit={limit * 3}"  # fetch extra since we'll filter
        )
        resp = requests.get(cdx_url, timeout=30, headers={"User-Agent": "ReconAI/1.0"})
        if resp.status_code == 200:
            data = resp.json()
            # First item is the header row
            for row in data[1:]:
                if len(row) >= 1:
                    urls.append(row[0])  # original URL
    except Exception as e:
        print(f"  [!] Wayback CDX fetch failed: {e}")

    return list(set(urls))


def filter_interesting_urls(urls: List[str]) -> List[Dict]:
    """Filter URLs to only keep potentially interesting ones."""
    interesting = []
    seen = set()

    for url in urls:
        try:
            parsed = urlparse(url)
            path = parsed.path.lower()
            ext = ""

            # Get file extension
            if "." in path.split("/")[-1]:
                ext = "." + path.split("/")[-1].rsplit(".", 1)[-1]

            # Skip boring extensions
            if ext in SKIP_EXTENSIONS:
                continue

            # Deduplicate by path (ignore query string differences)
            path_key = parsed.netloc + parsed.path
            if path_key in seen:
                continue
            seen.add(path_key)

            # Score interest level
            score = 0
            reasons = []

            # Check extension
            if ext in INTERESTING_EXTENSIONS:
                score += 3
                reasons.append(f"interesting extension ({ext})")

            # Check path patterns
            for pattern in SENSITIVE_PATTERNS:
                if re.search(pattern, path, re.IGNORECASE):
                    score += 2
                    reasons.append(f"sensitive pattern: {pattern}")
                    break  # Only count once per URL

            # Check query parameters
            if parsed.query:
                for param in ["id", "file", "path", "url", "redirect", "cmd", "exec", "token"]:
                    if param in parsed.query.lower():
                        score += 1
                        reasons.append(f"interesting parameter: {param}")
                        break

            if score > 0:
                interesting.append({
                    "url": url,
                    "path": parsed.path,
                    "score": score,
                    "reasons": reasons,
                })
        except Exception:
            continue

    # Sort by interest score
    interesting.sort(key=lambda x: x["score"], reverse=True)
    return interesting[:WAYBACK_LIMIT]


def check_if_alive(entry: Dict) -> Dict:
    """Check if a historical URL is still accessible today."""
    url = entry["url"]
    try:
        resp = requests.get(
            url,
            timeout=PORT_SCAN_TIMEOUT,
            verify=False,
            allow_redirects=True,
            headers={"User-Agent": "ReconAI/1.0"}
        )
        entry["current_status"] = resp.status_code
        entry["alive"] = resp.status_code < 400
        entry["content_length"] = len(resp.content)
        entry["server"] = resp.headers.get("Server", "")
        entry["content_type"] = resp.headers.get("Content-Type", "")

        # Check for sensitive content in response
        body = resp.text[:3000].lower()
        sensitive_hits = []
        for keyword in ["password", "secret", "api_key", "token", "private", "credentials"]:
            if keyword in body:
                sensitive_hits.append(keyword)
        entry["sensitive_content"] = sensitive_hits

    except requests.exceptions.SSLError:
        entry["current_status"] = 0
        entry["alive"] = False
        entry["error"] = "SSL Error"
    except requests.exceptions.ConnectionError:
        entry["current_status"] = 0
        entry["alive"] = False
        entry["error"] = "Connection refused"
    except Exception as e:
        entry["current_status"] = 0
        entry["alive"] = False
        entry["error"] = str(e)[:50]

    return entry


def run(domain: str, verbose: bool = False) -> Dict:
    """
    Main entry point for Wayback Machine endpoint discovery.
    """
    print(f"\n[*] Starting Wayback Machine scan for: {domain}")

    # Step 1: Fetch historical URLs
    print(f"  [+] Fetching historical URLs from Wayback Machine...")
    all_urls = fetch_wayback_urls(domain)
    print(f"      Retrieved {len(all_urls)} historical URLs")

    if not all_urls:
        print("  [!] No URLs found. The domain may not be indexed.")
        return {"domain": domain, "total_found": 0, "alive_count": 0, "findings": []}

    # Step 2: Filter for interesting ones
    print(f"  [+] Filtering for interesting/sensitive endpoints...")
    interesting = filter_interesting_urls(all_urls)
    print(f"      {len(interesting)} interesting endpoints identified")

    # Step 3: Check which ones are still alive
    print(f"  [+] Checking {len(interesting)} endpoints for liveness...")
    alive_findings = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = [executor.submit(check_if_alive, entry) for entry in interesting]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result.get("alive"):
                alive_findings.append(result)
                if verbose:
                    print(f"      [ALIVE] {result['url']} ({result['current_status']})")

    # Sort alive findings by score
    alive_findings.sort(key=lambda x: x.get("score", 0), reverse=True)

    # Count critical findings
    with_sensitive = [f for f in alive_findings if f.get("sensitive_content")]

    print(f"\n  [✓] Wayback scan complete:")
    print(f"      Historical URLs  : {len(all_urls)}")
    print(f"      Interesting URLs : {len(interesting)}")
    print(f"      Still alive      : {len(alive_findings)}")
    print(f"      With sensitive content: {len(with_sensitive)}")

    return {
        "domain": domain,
        "total_found": len(all_urls),
        "interesting_count": len(interesting),
        "alive_count": len(alive_findings),
        "sensitive_count": len(with_sensitive),
        "findings": alive_findings,
        "all_interesting": interesting,
    }
