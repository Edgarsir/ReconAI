import json, glob

files = sorted(glob.glob("reports/example*.json"))
latest = files[-1]
print(f"Reading: {latest}\n")

with open(latest, encoding="utf-8") as f:
    data = json.load(f)

analysis = data.get("analysis", {})

print("=" * 60)
print("AI SECURITY NARRATIVE (Gemini)")
print("=" * 60)
print(analysis.get("ai_summary") or "No AI narrative generated.")

print("\n" + "=" * 60)
print("TOP FINDINGS")
print("=" * 60)
for finding in analysis.get("top_findings", []):
    score = finding.get("risk_score", 0)
    ftype = finding.get("type", "")
    target = finding.get("target", "")
    print(f"  [{score}/10] {ftype.upper()} — {target}")
    for note in finding.get("notes", [])[:2]:
        print(f"    → {note}")

print("\n" + "=" * 60)
print("SHODAN — IP INFO")
print("=" * 60)
for host in data.get("shodan", {}).get("hosts", []):
    print(f"  IP      : {host.get('ip')}")
    print(f"  Org     : {host.get('org')}")
    print(f"  Country : {host.get('country')}")
    print(f"  Ports   : {host.get('open_ports')}")
    print(f"  CVEs    : {len(host.get('vulnerabilities', []))}")

print("\n" + "=" * 60)
print("BUG BOUNTY")
print("=" * 60)
bb = data.get("bugbounty", {})
print(f"  Total programs : {bb.get('total_programs', 0)}")
print(f"  In scope       : {bb.get('in_scope_count', 0)}")
print(f"  With bounty    : {bb.get('with_bounty_count', 0)}")
