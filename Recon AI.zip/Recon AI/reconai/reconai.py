#!/usr/bin/env python3
"""
██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗ █████╗ ██╗
██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║██╔══██╗██║
██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║███████║██║
██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║██╔══██║██║
██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║██║  ██║██║
╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝

ReconAI — AI-Powered Attack Surface Monitor v1.0
Continuous reconnaissance, vulnerability correlation, and AI-prioritized reporting.

Usage:
    python reconai.py -d example.com
    python reconai.py -d example.com --modules subdomains,ports,github
    python reconai.py -d example.com --full --verbose
    python reconai.py -d example.com --org mycompany --shodan

DISCLAIMER: For authorized security testing only.
"""

import argparse
import sys
import os
import time
import json
from datetime import datetime

# Ensure project root is in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules import (
    subdomain_enum,
    port_scanner,
    github_scanner,
    wayback_scanner,
    shodan_scanner,
    ai_engine,
    report_generator,
    bugbounty,
)
from config.settings import SHODAN_API_KEY, GITHUB_TOKEN, GEMINI_API_KEY

BANNER = """
\033[36m
██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗ █████╗ ██╗
██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║██╔══██╗██║
██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║███████║██║
██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║██╔══██║██║
██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║██║  ██║██║
╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝
\033[0m
\033[90mAI-Powered Attack Surface Monitor v1.0\033[0m
\033[31mFor authorized security testing only.\033[0m
"""

EMPTY_RESULT = {
    "subdomains": [], "live_count": 0, "total_found": 0, "takeover_risks": 0
}


def print_config_status():
    """Print which API keys are configured."""
    print("\n\033[90m[config]\033[0m API Keys:")
    print(f"  Shodan  : {'✓ configured' if SHODAN_API_KEY else '✗ not set (set SHODAN_API_KEY)'}")
    print(f"  GitHub  : {'✓ configured' if GITHUB_TOKEN else '✗ not set (set GITHUB_TOKEN, rate limited)'}")
    print(f"  Gemini  : {'✓ configured (AI analysis enabled)' if GEMINI_API_KEY else '✗ not set (rule-based only)'}")
    print()


def parse_args():
    parser = argparse.ArgumentParser(
        description="ReconAI — AI-Powered Attack Surface Monitor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python reconai.py -d example.com
  python reconai.py -d example.com --full --verbose
  python reconai.py -d example.com --modules subdomains,ports
  python reconai.py -d example.com --org mycompany --no-github
  python reconai.py -d example.com --output-dir /tmp/reports
        """
    )

    parser.add_argument(
        "-d", "--domain", required=True,
        help="Target domain to scan (e.g. example.com)"
    )
    parser.add_argument(
        "--org",
        help="GitHub organization name (auto-inferred from domain if not set)"
    )
    parser.add_argument(
        "--modules",
        help="Comma-separated list of modules to run: subdomains,ports,github,wayback,shodan,ai",
        default="subdomains,ports,github,wayback,shodan,ai"
    )
    parser.add_argument(
        "--full", action="store_true",
        help="Run all modules (equivalent to --modules subdomains,ports,github,wayback,shodan,bugbounty,ai)"
    )
    parser.add_argument(
        "--no-github", action="store_true",
        help="Skip GitHub scanning"
    )
    parser.add_argument(
        "--no-shodan", action="store_true",
        help="Skip Shodan scanning"
    )
    parser.add_argument(
        "--no-wayback", action="store_true",
        help="Skip Wayback Machine scanning"
    )
    parser.add_argument(
        "--no-bugbounty", action="store_true",
        help="Skip bug bounty lookup"
    )
    parser.add_argument(
        "--no-ai", action="store_true",
        help="Skip AI analysis (use rule-based only)"
    )
    parser.add_argument(
        "--ports-only", action="store_true",
        help="Only scan ports on the main domain IP"
    )
    parser.add_argument(
        "--output-dir", default="reports",
        help="Directory for output reports (default: ./reports)"
    )
    parser.add_argument(
        "--output-json", action="store_true",
        help="Also output raw JSON results"
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Verbose output"
    )
    parser.add_argument(
        "--no-report", action="store_true",
        help="Skip HTML report generation (print summary only)"
    )

    return parser.parse_args()


def resolve_modules(args) -> set:
    """Determine which modules to run."""
    if args.full:
        modules = {"subdomains", "ports", "github", "wayback", "shodan", "bugbounty", "ai"}
    else:
        modules = set(m.strip() for m in args.modules.split(","))

    if args.no_github:
        modules.discard("github")
    if args.no_shodan:
        modules.discard("shodan")
    if args.no_wayback:
        modules.discard("wayback")
    if args.no_ai:
        modules.discard("ai")
    if hasattr(args, 'no_bugbounty') and args.no_bugbounty:
        modules.discard("bugbounty")

    return modules


def print_final_summary(domain: str, analysis: dict, bugbounty_data: dict, report_path: str, duration: float):
    """Print a clean final summary to terminal."""
    overall = analysis.get("overall_risk", "UNKNOWN")
    colors = {
        "CRITICAL": "\033[91m",
        "HIGH": "\033[93m",
        "MEDIUM": "\033[33m",
        "LOW": "\033[92m",
    }
    c = colors.get(overall, "\033[0m")
    reset = "\033[0m"

    # Bug bounty summary line
    bb_in  = bugbounty_data.get("in_scope_count", 0)
    bb_pay = bugbounty_data.get("with_bounty_count", 0)
    if bb_in > 0:
        bb_line = f"\033[92m{bb_in} program(s) in scope, {bb_pay} with bounty\033[0m"
    elif bugbounty_data.get("total_programs", 0) > 0:
        bb_line = f"\033[91mNot in scope on known programs\033[0m"
    else:
        bb_line = "No programs found"

    print(f"""
\033[90m{'─' * 60}\033[0m
\033[1mSCAN COMPLETE — {domain}\033[0m
\033[90m{'─' * 60}\033[0m
  Overall Risk    : {c}{overall}{reset}
  Total Findings  : {analysis.get('total_findings', 0)}
  Critical        : \033[91m{analysis.get('critical_count', 0)}\033[0m
  High            : \033[93m{analysis.get('high_count', 0)}\033[0m
  Medium          : \033[33m{analysis.get('medium_count', 0)}\033[0m
  Low             : \033[92m{analysis.get('low_count', 0)}\033[0m
  Bug Bounty      : {bb_line}
  Scan Duration   : {duration:.1f}s
  AI Analysis     : {'✓ enabled' if analysis.get('ai_used') else '✗ rule-based'}
\033[90m{'─' * 60}\033[0m""")

    if report_path:
        print(f"  \033[36mReport saved to: {report_path}\033[0m")

    # Print top 3 critical findings
    critical = [f for f in analysis.get("top_findings", []) if f.get("risk_score", 0) >= 9]
    if critical:
        print(f"\n\033[91m  TOP CRITICAL FINDINGS:\033[0m")
        for f in critical[:3]:
            print(f"  ⚠  [{f.get('type','').upper()}] {f.get('target','')}")
            for note in f.get("notes", [])[:1]:
                print(f"     → {note}")

    print()


def main():
    print(BANNER)
    args = parse_args()
    print_config_status()

    domain = args.domain.lower().strip()
    modules = resolve_modules(args)

    print(f"\033[1m[*] Target: {domain}\033[0m")
    print(f"[*] Modules: {', '.join(sorted(modules))}")
    print(f"[*] Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()

    start_time = time.time()

    # ── Run modules ─────────────────────────────────────────────────────────

    # 0. Bug bounty scope check (runs first — tells you if target is in scope)
    bugbounty_data = {
        "total_programs": 0, "in_scope_count": 0, "out_of_scope_count": 0,
        "with_bounty_count": 0, "in_scope": [], "out_of_scope": [],
        "unknown": [], "all_programs": [],
    }
    if "bugbounty" in modules:
        bugbounty_data = bugbounty.run(domain, verbose=args.verbose)

        # Warn if target is out of scope on all known programs
        if bugbounty_data["out_of_scope_count"] > 0 and bugbounty_data["in_scope_count"] == 0:
            print(f"\n  \033[91m[!] WARNING: {domain} appears OUT OF SCOPE on known bug bounty programs.\033[0m")
            print(f"      Proceed only if you have explicit written permission.\n")
        elif bugbounty_data["in_scope_count"] > 0:
            print(f"\n  \033[92m[✓] TARGET IS IN SCOPE — Happy hunting!\033[0m\n")

    # 1. Subdomain enumeration
    subdomain_data = {"subdomains": [], "live_count": 0, "total_found": 0, "takeover_risks": 0}
    if "subdomains" in modules:
        subdomain_data = subdomain_enum.run(domain, verbose=args.verbose)

    # 2. Port scanning
    # Scan main domain + top live subdomains
    port_data = {}
    if "ports" in modules:
        scan_targets = [domain]
        if subdomain_data.get("subdomains"):
            # Add top 10 live subdomains to scan
            live_subs = [s["subdomain"] for s in subdomain_data["subdomains"]
                         if s.get("resolved") and s.get("ips")][:10]
            scan_targets.extend(live_subs)

        port_data = port_scanner.run(scan_targets, verbose=args.verbose)

    # 3. GitHub secret scanning
    github_data = {"total_leaks": 0, "critical": 0, "high": 0, "medium": 0, "findings": []}
    if "github" in modules:
        github_data = github_scanner.run(domain, org=args.org, verbose=args.verbose)

    # 4. Wayback Machine discovery
    wayback_data = {"total_found": 0, "alive_count": 0, "findings": []}
    if "wayback" in modules:
        wayback_data = wayback_scanner.run(domain, verbose=args.verbose)

    # 5. Shodan intelligence
    shodan_data = {"total_ips": 0, "total_vulns": 0, "critical_vulns": 0, "hosts": []}
    if "shodan" in modules:
        # Pass discovered IPs from subdomains
        known_ips = []
        for sub in subdomain_data.get("subdomains", []):
            known_ips.extend(sub.get("ips", []))
        shodan_data = shodan_scanner.run(domain, ips=list(set(known_ips)), verbose=args.verbose)

    # 6. AI Risk Prioritization
    analysis = {}
    if "ai" in modules:
        analysis = ai_engine.run(
            domain=domain,
            subdomain_data=subdomain_data,
            port_data=port_data,
            github_data=github_data,
            wayback_data=wayback_data,
            shodan_data=shodan_data,
            verbose=args.verbose,
        )
    else:
        # Minimal analysis if AI module skipped
        analysis = {
            "overall_risk": "UNKNOWN", "overall_score": 0,
            "total_findings": 0, "critical_count": 0,
            "high_count": 0, "medium_count": 0, "low_count": 0,
            "top_findings": [], "all_findings": [], "remediation": [],
            "ai_summary": None, "ai_used": False,
        }

    scan_duration = time.time() - start_time

    # 7. Report generation
    report_path = None
    if not args.no_report:
        report_path = report_generator.run(
            domain=domain,
            analysis=analysis,
            subdomain_data=subdomain_data,
            port_data=port_data,
            github_data=github_data,
            wayback_data=wayback_data,
            shodan_data=shodan_data,
            bugbounty_data=bugbounty_data,
            output_dir=args.output_dir,
            scan_duration=scan_duration,
        )

    # Print final summary
    print_final_summary(domain, analysis, bugbounty_data, report_path, scan_duration)


if __name__ == "__main__":
    main()
